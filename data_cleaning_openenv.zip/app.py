from __future__ import annotations

from openenv.core import create_fastapi_app

from data_cleaning_env import DataCleaningAction, DataCleaningEnv, DataCleaningObservation
from data_cleaning_env.tasks import list_task_configs

shared_env = DataCleaningEnv()
app = create_fastapi_app(lambda: shared_env, DataCleaningAction, DataCleaningObservation)


@app.get("/")
def root() -> dict:
    return {
        "name": "data_cleaning_pipeline",
        "status": "ok",
        "tasks": [task.task_id for task in list_task_configs()],
    }
