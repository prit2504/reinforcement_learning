from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, Optional

import numpy as np
import pandas as pd
from openenv.core import Environment

from .graders import grade_task
from .models import ColumnStats, DataCleaningAction, DataCleaningObservation, DataCleaningState, OperationName
from .tasks import GeneratedTask, build_task_catalog


@dataclass
class EpisodeState:
    task: GeneratedTask
    initial_dataframe: pd.DataFrame
    dataframe: pd.DataFrame
    steps_used: int
    quality_score: float
    done: bool
    last_action: Optional[str] = None
    last_action_error: Optional[str] = None
    history: list[Dict[str, Any]] | None = None


class DataCleaningEnv(Environment[DataCleaningAction, DataCleaningObservation, DataCleaningState]):
    def __init__(self, task_id: str = "sales_csv") -> None:
        super().__init__()
        self._task_catalog = build_task_catalog()
        if task_id not in self._task_catalog:
            raise KeyError(f"Unknown task_id '{task_id}'")
        self.task_id = task_id
        self._episode: Optional[EpisodeState] = None

    def reset(
        self,
        seed: Optional[int] = None,
        episode_id: Optional[str] = None,
        task_id: Optional[str] = None,
        **_: Any,
    ) -> DataCleaningObservation:
        if task_id:
            if task_id not in self._task_catalog:
                raise KeyError(f"Unknown task_id '{task_id}'")
            self.task_id = task_id

        task = self._task_catalog[self.task_id]()
        quality_score, metrics = grade_task(task, task.dataframe)
        self._episode = EpisodeState(
            task=task,
            initial_dataframe=task.dataframe.copy(deep=True),
            dataframe=task.dataframe.copy(deep=True),
            steps_used=0,
            quality_score=quality_score,
            done=False,
            history=[],
        )
        return self._build_observation(
            reward=0.0,
            done=False,
            metadata={
                "episode_id": episode_id,
                "seed": seed if seed is not None else task.config.seed,
                "info": {
                    "score": quality_score,
                    "reward_breakdown": {},
                    "changed": False,
                    "rows_before": len(task.dataframe),
                    "rows_after": len(task.dataframe),
                    "columns_before": len(task.dataframe.columns),
                    "columns_after": len(task.dataframe.columns),
                    "grader_metrics": metrics,
                    "terminated_reason": None,
                },
            },
        )

    @property
    def state(self) -> DataCleaningState:
        episode = self._require_episode()
        return DataCleaningState(
            episode_id=None,
            step_count=episode.steps_used,
            task_id=episode.task.config.task_id,
            task_name=episode.task.config.name,
            difficulty=episode.task.config.difficulty,
            seed=episode.task.config.seed,
            quality_score=episode.quality_score,
            step_budget=episode.task.config.step_budget,
            done=episode.done,
            history=episode.history or [],
            last_action_error=episode.last_action_error,
        )

    def step(
        self,
        action: DataCleaningAction,
        timeout_s: Optional[float] = None,
        **_: Any,
    ) -> DataCleaningObservation:
        episode = self._require_episode()
        if episode.done:
            return self._build_observation(
                reward=0.0,
                done=True,
                metadata={
                    "info": {
                        "score": episode.quality_score,
                        "reward_breakdown": {"episode_closed": 0.0},
                        "changed": False,
                        "rows_before": len(episode.dataframe),
                        "rows_after": len(episode.dataframe),
                        "columns_before": len(episode.dataframe.columns),
                        "columns_after": len(episode.dataframe.columns),
                        "grader_metrics": {},
                        "terminated_reason": "completed",
                    }
                },
            )

        task = episode.task
        if action.op not in task.config.allowed_operations:
            episode.last_action_error = f"Operation '{action.op.value}' not allowed for task '{task.config.task_id}'"
            return self._finalize_invalid_step(
                action=action,
                reward=0.0,
                changed=False,
                rows_before=len(episode.dataframe),
                columns_before=len(episode.dataframe.columns),
                terminated_reason="invalid_action",
            )

        rows_before = len(episode.dataframe)
        columns_before = len(episode.dataframe.columns)
        df_before = episode.dataframe.copy(deep=True)

        try:
            updated_df = self._apply_action(episode.dataframe.copy(deep=True), action, task)
            changed = not updated_df.equals(df_before)
            episode.dataframe = updated_df
            episode.last_action_error = None
        except Exception as exc:
            changed = False
            episode.last_action_error = str(exc)

        previous_quality = episode.quality_score
        episode.steps_used += 1
        episode.last_action = self._action_repr(action)

        new_quality, metrics = grade_task(task, episode.dataframe)
        episode.quality_score = new_quality

        quality_delta = max(new_quality - previous_quality, 0.0)
        reward_breakdown = {"quality_delta": round(quality_delta, 6)}
        reward = quality_delta

        if not changed:
            reward_breakdown["no_op_penalty"] = -0.05
            reward = max(0.0, reward - 0.05)

        data_loss_penalty = self._data_loss_penalty(df_before, episode.dataframe)
        if data_loss_penalty:
            reward_breakdown["data_loss_penalty"] = -data_loss_penalty
            reward = max(0.0, reward - data_loss_penalty)

        terminated_reason: Optional[str] = None
        if episode.steps_used >= task.config.step_budget:
            episode.done = True
            terminated_reason = "budget_exhausted"
        elif new_quality >= task.config.target_score:
            episode.done = True
            reward_breakdown["target_bonus"] = 0.2
            reward = min(1.0, reward + 0.2)
            terminated_reason = "max_score"

        if episode.history is not None:
            episode.history.append(
                {
                    "step": episode.steps_used,
                    "action": episode.last_action,
                    "reward": round(reward, 6),
                    "quality_score": round(new_quality, 6),
                    "error": episode.last_action_error,
                }
            )

        return self._build_observation(
            reward=round(reward, 6),
            done=episode.done,
            metadata={
                "info": {
                    "score": new_quality,
                    "reward_breakdown": reward_breakdown,
                    "changed": changed,
                    "rows_before": rows_before,
                    "rows_after": len(episode.dataframe),
                    "columns_before": columns_before,
                    "columns_after": len(episode.dataframe.columns),
                    "grader_metrics": metrics,
                    "terminated_reason": terminated_reason,
                }
            },
        )

    def _finalize_invalid_step(
        self,
        action: DataCleaningAction,
        reward: float,
        changed: bool,
        rows_before: int,
        columns_before: int,
        terminated_reason: Optional[str],
    ) -> DataCleaningObservation:
        episode = self._require_episode()
        episode.steps_used += 1
        episode.last_action = self._action_repr(action)
        if episode.steps_used >= episode.task.config.step_budget:
            episode.done = True
            terminated_reason = terminated_reason or "budget_exhausted"

        if episode.history is not None:
            episode.history.append(
                {
                    "step": episode.steps_used,
                    "action": episode.last_action,
                    "reward": round(reward, 6),
                    "quality_score": round(episode.quality_score, 6),
                    "error": episode.last_action_error,
                }
            )

        return self._build_observation(
            reward=reward,
            done=episode.done,
            metadata={
                "info": {
                    "score": episode.quality_score,
                    "reward_breakdown": {"invalid_action": reward},
                    "changed": changed,
                    "rows_before": rows_before,
                    "rows_after": len(episode.dataframe),
                    "columns_before": columns_before,
                    "columns_after": len(episode.dataframe.columns),
                    "grader_metrics": {},
                    "terminated_reason": terminated_reason,
                }
            },
        )

    def _build_observation(
        self,
        reward: Optional[float] = None,
        done: bool = False,
        metadata: Optional[Dict[str, Any]] = None,
    ) -> DataCleaningObservation:
        episode = self._require_episode()
        return DataCleaningObservation(
            done=done,
            reward=reward,
            metadata=metadata or {},
            task_id=episode.task.config.task_id,
            task_name=episode.task.config.name,
            instructions=episode.task.config.objective,
            df_preview=self._preview_rows(episode.dataframe),
            column_stats=self._column_stats(episode.dataframe),
            issue_flags=self._issue_flags(episode.dataframe, episode.task),
            quality_score=round(episode.quality_score, 6),
            steps_used=episode.steps_used,
            step_budget=episode.task.config.step_budget,
            last_action=episode.last_action,
            last_action_error=episode.last_action_error,
        )

    def save_episode_files(self, output_dir: str | Path) -> dict[str, str]:
        episode = self._require_episode()
        target_dir = Path(output_dir)
        target_dir.mkdir(parents=True, exist_ok=True)

        raw_path = target_dir / "raw.csv"
        processed_path = target_dir / "processed.csv"

        episode.initial_dataframe.to_csv(raw_path, index=False)
        episode.dataframe.to_csv(processed_path, index=False)

        return {
            "raw": str(raw_path),
            "processed": str(processed_path),
        }

    def _apply_action(
        self, df: pd.DataFrame, action: DataCleaningAction, task: GeneratedTask
    ) -> pd.DataFrame:
        op = action.op
        column = action.column
        params = action.params

        if op == OperationName.FILL_NULLS:
            strategy = params.get("strategy", "median")
            return self._fill_nulls(df, column, strategy)
        if op == OperationName.DROP_DUPLICATES:
            subset = params.get("subset")
            return df.drop_duplicates(subset=subset, ignore_index=True)
        if op == OperationName.CAST_TYPE:
            return self._cast_type(df, column, params.get("dtype"))
        if op == OperationName.CLIP_OUTLIERS:
            return self._clip_outliers(df, column, float(params.get("zmax", 3.0)))
        if op == OperationName.NORMALIZE:
            method = params.get("method", "lowercase")
            return self._normalize(df, column, method)
        if op == OperationName.RENAME_COLUMN:
            new_name = params.get("new_name")
            if not new_name:
                raise ValueError("rename_column requires params.new_name")
            return df.rename(columns={column: new_name})
        if op == OperationName.DROP_COLUMN:
            return df.drop(columns=[column])
        if op == OperationName.PARSE_DATES:
            return self._parse_dates(df, column)
        if op == OperationName.APPLY_CONSTRAINT:
            return self._apply_constraint(df, column, params, task)
        raise ValueError(f"Unsupported operation: {op.value}")

    def _fill_nulls(self, df: pd.DataFrame, column: str, strategy: str) -> pd.DataFrame:
        if column not in df.columns:
            raise ValueError(f"Unknown column '{column}'")
        series = df[column]
        if strategy == "median":
            fill_value = pd.to_numeric(series, errors="coerce").median()
        elif strategy == "mode":
            mode = series.mode(dropna=True)
            fill_value = mode.iloc[0] if not mode.empty else None
        elif strategy == "zero":
            fill_value = 0
        elif strategy == "unknown":
            fill_value = "unknown"
        else:
            raise ValueError(f"Unsupported fill strategy '{strategy}'")
        df[column] = series.fillna(fill_value)
        return df

    def _cast_type(self, df: pd.DataFrame, column: str, dtype: Optional[str]) -> pd.DataFrame:
        if column not in df.columns:
            raise ValueError(f"Unknown column '{column}'")
        if dtype not in {"int", "float", "str"}:
            raise ValueError("cast_type requires params.dtype in {'int', 'float', 'str'}")
        if dtype == "int":
            df[column] = pd.to_numeric(df[column], errors="coerce").astype("Int64")
        elif dtype == "float":
            df[column] = pd.to_numeric(df[column], errors="coerce")
        else:
            df[column] = df[column].astype(str)
        return df

    def _clip_outliers(self, df: pd.DataFrame, column: str, zmax: float) -> pd.DataFrame:
        if column not in df.columns:
            raise ValueError(f"Unknown column '{column}'")
        values = pd.to_numeric(df[column], errors="coerce")
        mean = float(values.mean())
        std = float(values.std(ddof=0))
        if std == 0 or np.isnan(std):
            return df
        z_scores = (values - mean) / std
        clipped = values.mask(z_scores.abs() > zmax, other=values.clip(mean - zmax * std, mean + zmax * std))
        df[column] = clipped
        return df

    def _normalize(self, df: pd.DataFrame, column: str, method: str) -> pd.DataFrame:
        if column not in df.columns:
            raise ValueError(f"Unknown column '{column}'")
        series = df[column].astype(str)
        if method == "lowercase":
            df[column] = series.str.lower().str.strip()
        elif method == "uppercase":
            df[column] = series.str.upper().str.strip()
        else:
            raise ValueError(f"Unsupported normalize method '{method}'")
        return df

    def _parse_dates(self, df: pd.DataFrame, column: str) -> pd.DataFrame:
        if column not in df.columns:
            raise ValueError(f"Unknown column '{column}'")
        df[column] = pd.to_datetime(df[column], errors="coerce")
        return df

    def _apply_constraint(
        self, df: pd.DataFrame, column: str, params: Dict[str, Any], task: GeneratedTask
    ) -> pd.DataFrame:
        rule = params.get("rule")
        if rule == "positive":
            numeric = pd.to_numeric(df[column], errors="coerce")
            df[column] = numeric.where(numeric > 0, other=1)
            return df
        if rule == "reference_exists":
            ref_name = params.get("reference_table")
            ref_column = params.get("reference_column", column)
            if ref_name not in task.reference_tables:
                raise ValueError(f"Unknown reference table '{ref_name}'")
            valid = set(task.reference_tables[ref_name][ref_column].astype(str))
            invalid_mask = ~df[column].astype(str).isin(valid)
            replacement = task.reference_tables[ref_name][ref_column].iloc[0]
            df.loc[invalid_mask, column] = replacement
            return df
        raise ValueError(f"Unsupported constraint rule '{rule}'")

    def _preview_rows(self, df: pd.DataFrame) -> list[Dict[str, Any]]:
        preview = df.head(5).replace({np.nan: None})
        return preview.to_dict(orient="records")

    def _column_stats(self, df: pd.DataFrame) -> list[ColumnStats]:
        stats: list[ColumnStats] = []
        for column in df.columns:
            series = df[column]
            numeric = pd.to_numeric(series, errors="coerce")
            min_value: Any = None
            max_value: Any = None
            if numeric.notna().any():
                min_value = float(numeric.min())
                max_value = float(numeric.max())
            sample_values = series.dropna().astype(str).head(3).tolist()
            notes = []
            if pd.api.types.is_object_dtype(series):
                notes.append("string_like")
            if series.isna().any():
                notes.append("contains_nulls")
            stats.append(
                ColumnStats(
                    column=column,
                    dtype=str(series.dtype),
                    null_fraction=round(float(series.isna().mean()), 6),
                    unique_count=int(series.nunique(dropna=True)),
                    sample_values=sample_values,
                    min_value=min_value,
                    max_value=max_value,
                    notes=notes,
                )
            )
        return stats

    def _issue_flags(self, df: pd.DataFrame, task: GeneratedTask) -> list[str]:
        issues: list[str] = []
        for column in df.columns:
            null_frac = float(df[column].isna().mean())
            if null_frac > 0.0:
                issues.append(f"{column}: {null_frac:.1%} nulls")
        duplicate_rows = int(df.duplicated().sum())
        if duplicate_rows:
            issues.append(f"dataset: {duplicate_rows} duplicate rows")
        if task.config.task_id == "patient_records":
            parsed_ratio = float(pd.to_datetime(df["admission_date"], errors="coerce").notna().mean())
            if parsed_ratio < 1.0:
                issues.append(f"admission_date: only {parsed_ratio:.1%} parse cleanly")
        if task.config.task_id == "ecommerce_orders":
            if "status" not in df.columns or "total_amount" not in df.columns:
                issues.append("schema drift: expected status and total_amount columns")
            invalid_quantity = float((pd.to_numeric(df["quantity"], errors="coerce") <= 0).mean())
            if invalid_quantity > 0:
                issues.append(f"quantity: {invalid_quantity:.1%} non-positive values")
        return issues[:10]

    def _data_loss_penalty(self, before_df: pd.DataFrame, after_df: pd.DataFrame) -> float:
        if len(before_df) == 0:
            return 0.0
        loss_fraction = max(len(before_df) - len(after_df), 0) / len(before_df)
        return 0.1 if loss_fraction > 0.2 else 0.0

    def _action_repr(self, action: DataCleaningAction) -> str:
        return f"{action.op.value}(column={action.column}, params={action.params})"

    def _require_episode(self) -> EpisodeState:
        if self._episode is None:
            raise RuntimeError("Environment not initialized. Call reset() first.")
        return self._episode
