from __future__ import annotations

from typing import Dict

import pandas as pd

from .tasks import GeneratedTask


def _clamp(score: float) -> float:
    return max(0.0, min(1.0, round(score, 6)))


def _null_score(df: pd.DataFrame, columns: list[str]) -> float:
    if not columns:
        return 1.0
    frac = sum(float(df[col].isna().mean()) for col in columns) / len(columns)
    return _clamp(1.0 - frac)


def _duplicate_score(df: pd.DataFrame) -> float:
    if len(df) == 0:
        return 0.0
    dup_frac = float(df.duplicated().mean())
    return _clamp(1.0 - dup_frac)


def _dtype_score(df: pd.DataFrame, expected: Dict[str, str]) -> float:
    hits = 0
    for column, expected_type in expected.items():
        series = df[column]
        if expected_type == "numeric":
            hits += int(pd.api.types.is_numeric_dtype(series))
        elif expected_type == "datetime":
            hits += int(pd.api.types.is_datetime64_any_dtype(series))
        else:
            hits += int(str(series.dtype) == expected_type)
    return _clamp(hits / max(len(expected), 1))


def _outlier_score(df: pd.DataFrame, column: str) -> float:
    values = pd.to_numeric(df[column], errors="coerce").dropna()
    if values.empty:
        return 0.0
    q1 = float(values.quantile(0.25))
    q3 = float(values.quantile(0.75))
    iqr = q3 - q1
    if iqr == 0:
        return 1.0
    lower = q1 - 1.5 * iqr
    upper = q3 + 1.5 * iqr
    outlier_frac = float(((values < lower) | (values > upper)).mean())
    return _clamp(1.0 - outlier_frac)


def _date_parse_score(df: pd.DataFrame, column: str) -> float:
    series = df[column]
    if pd.api.types.is_datetime64_any_dtype(series):
        return 1.0
    parsed = pd.to_datetime(series, errors="coerce")
    return _clamp(float(parsed.notna().mean()))


def _referential_score(df: pd.DataFrame, reference: pd.DataFrame, column: str) -> float:
    valid = set(reference[column].astype(str))
    observed = df[column].astype(str)
    return _clamp(float(observed.isin(valid).mean()))


def grade_sales_csv(task: GeneratedTask, df: pd.DataFrame) -> tuple[float, Dict[str, float]]:
    metrics = {
        "null_score": _null_score(df, ["sales_rep", "unit_price"]),
        "duplicate_score": _duplicate_score(df),
    }
    score = _clamp(0.55 * metrics["null_score"] + 0.45 * metrics["duplicate_score"])
    return score, metrics


def grade_patient_records(task: GeneratedTask, df: pd.DataFrame) -> tuple[float, Dict[str, float]]:
    metrics = {
        "dtype_score": _dtype_score(df, {"age": "numeric", "admission_date": "datetime"}),
        "outlier_score": _outlier_score(df, "lab_result"),
        "date_parse_score": _date_parse_score(df, "admission_date"),
    }
    score = _clamp(
        0.35 * metrics["dtype_score"]
        + 0.3 * metrics["outlier_score"]
        + 0.35 * metrics["date_parse_score"]
    )
    return score, metrics


def grade_ecommerce_orders(task: GeneratedTask, df: pd.DataFrame) -> tuple[float, Dict[str, float]]:
    customers = task.reference_tables["customers"]
    metrics = {
        "schema_score": _clamp(float({"status", "total_amount"}.issubset(set(df.columns)))),
        "referential_score": _referential_score(df, customers, "customer_id"),
        "duplicate_score": _duplicate_score(df),
        "null_score": _null_score(df, ["unit_price"]),
        "quantity_score": _clamp(float((pd.to_numeric(df["quantity"], errors="coerce") > 0).mean())),
        "date_parse_score": _date_parse_score(df, "order_date"),
    }
    score = _clamp(
        0.15 * metrics["schema_score"]
        + 0.2 * metrics["referential_score"]
        + 0.15 * metrics["duplicate_score"]
        + 0.15 * metrics["null_score"]
        + 0.15 * metrics["quantity_score"]
        + 0.2 * metrics["date_parse_score"]
    )
    return score, metrics


def grade_task(task: GeneratedTask, df: pd.DataFrame) -> tuple[float, Dict[str, float]]:
    task_id = task.config.task_id
    if task_id == "sales_csv":
        return grade_sales_csv(task, df)
    if task_id == "patient_records":
        return grade_patient_records(task, df)
    if task_id == "ecommerce_orders":
        return grade_ecommerce_orders(task, df)
    raise KeyError(f"Unknown task id: {task_id}")
