from __future__ import annotations

from enum import Enum
from typing import Any, Dict, List, Literal, Optional

from openenv.core import Action, Observation, State
from pydantic import BaseModel, Field, field_validator

class TaskDifficulty(str, Enum):
    EASY = "easy"
    MEDIUM = "medium"
    HARD = "hard"


class OperationName(str, Enum):
    FILL_NULLS = "fill_nulls"
    DROP_DUPLICATES = "drop_duplicates"
    CAST_TYPE = "cast_type"
    CLIP_OUTLIERS = "clip_outliers"
    NORMALIZE = "normalize"
    RENAME_COLUMN = "rename_column"
    DROP_COLUMN = "drop_column"
    PARSE_DATES = "parse_dates"
    APPLY_CONSTRAINT = "apply_constraint"


class ColumnStats(BaseModel):
    column: str
    dtype: str
    null_fraction: float = Field(ge=0.0, le=1.0)
    unique_count: int = Field(ge=0)
    sample_values: List[Any] = Field(default_factory=list)
    min_value: Optional[float | str] = None
    max_value: Optional[float | str] = None
    notes: List[str] = Field(default_factory=list)


class DataCleaningObservation(Observation):
    task_id: str
    task_name: str
    instructions: str
    df_preview: List[Dict[str, Any]] = Field(default_factory=list)
    column_stats: List[ColumnStats] = Field(default_factory=list)
    issue_flags: List[str] = Field(default_factory=list)
    quality_score: float = Field(ge=0.0, le=1.0)
    steps_used: int = Field(ge=0)
    step_budget: int = Field(ge=1)
    last_action: Optional[str] = None
    last_action_error: Optional[str] = None


class DataCleaningAction(Action):
    op: OperationName
    column: Optional[str] = None
    params: Dict[str, Any] = Field(default_factory=dict)

    @field_validator("column")
    @classmethod
    def validate_column_required(cls, value: Optional[str], info: Any) -> Optional[str]:
        op = info.data.get("op")
        ops_without_column = {
            OperationName.DROP_DUPLICATES,
        }
        if op not in ops_without_column and not value:
            raise ValueError(f"column is required for operation '{op}'")
        return value


class StepInfo(BaseModel):
    score: float = Field(ge=0.0, le=1.0)
    reward_breakdown: Dict[str, float] = Field(default_factory=dict)
    changed: bool = False
    rows_before: int = Field(ge=0)
    rows_after: int = Field(ge=0)
    columns_before: int = Field(ge=0)
    columns_after: int = Field(ge=0)
    grader_metrics: Dict[str, float] = Field(default_factory=dict)
    terminated_reason: Optional[
        Literal["completed", "budget_exhausted", "invalid_action", "max_score"]
    ] = None


class StepResult(BaseModel):
    observation: DataCleaningObservation
    reward: float = Field(ge=0.0, le=1.0)
    done: bool = False
    info: StepInfo


class DataCleaningState(State):
    task_id: str
    task_name: str
    difficulty: TaskDifficulty
    seed: int
    quality_score: float = Field(ge=0.0, le=1.0)
    step_budget: int = Field(ge=1)
    done: bool = False
    history: List[Dict[str, Any]] = Field(default_factory=list)
    last_action_error: Optional[str] = None


class TaskConfig(BaseModel):
    task_id: str
    name: str
    difficulty: TaskDifficulty
    description: str
    objective: str
    seed: int
    step_budget: int = Field(ge=1)
    target_score: float = Field(default=0.85, ge=0.0, le=1.0)
    dataset_rows: int = Field(ge=1)
    allowed_operations: List[OperationName] = Field(default_factory=list)
    expected_issues: List[str] = Field(default_factory=list)


class TaskCatalog(BaseModel):
    benchmark_name: str = "data_cleaning_pipeline"
    tasks: List[TaskConfig]
