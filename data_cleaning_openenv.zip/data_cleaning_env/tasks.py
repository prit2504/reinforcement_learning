from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Callable, Dict, List

import numpy as np
import pandas as pd

from .models import OperationName, TaskConfig, TaskDifficulty


ARTIFACTS_DIR = Path(__file__).resolve().parent.parent / "artifacts"


@dataclass(frozen=True)
class GeneratedTask:
    config: TaskConfig
    dataframe: pd.DataFrame
    reference_tables: Dict[str, pd.DataFrame]
    clean_dataframe: pd.DataFrame


TaskFactory = Callable[[], GeneratedTask]


def _rng(seed: int) -> np.random.Generator:
    return np.random.default_rng(seed)


def _save_task_artifacts(
    task_id: str,
    dirty_df: pd.DataFrame,
    clean_df: pd.DataFrame,
    reference_tables: Dict[str, pd.DataFrame] | None = None,
) -> None:
    task_dir = ARTIFACTS_DIR / task_id
    task_dir.mkdir(parents=True, exist_ok=True)

    dirty_df.to_csv(task_dir / "raw.csv", index=False)
    clean_df.to_csv(task_dir / "processed.csv", index=False)

    for name, table in (reference_tables or {}).items():
        table.to_csv(task_dir / f"reference_{name}.csv", index=False)


def build_sales_task() -> GeneratedTask:
    seed = 101
    rng = _rng(seed)
    row_count = 1200

    sales = pd.DataFrame(
        {
            "order_id": [f"S-{10000 + i}" for i in range(row_count)],
            "region": rng.choice(["north", "south", "east", "west"], size=row_count),
            "sales_rep": rng.choice(["ava", "liam", "noah", "mia"], size=row_count),
            "units_sold": rng.integers(1, 20, size=row_count),
            "unit_price": rng.normal(42.0, 7.0, size=row_count).round(2),
        }
    )
    sales["revenue"] = (sales["units_sold"] * sales["unit_price"]).round(2)

    clean = sales.copy(deep=True)
    dirty = clean.copy(deep=True)

    dirty.loc[rng.choice(row_count, size=180, replace=False), "sales_rep"] = None
    dirty.loc[rng.choice(row_count, size=160, replace=False), "unit_price"] = np.nan
    duplicate_rows = dirty.sample(n=200, random_state=seed)
    dirty = pd.concat([dirty, duplicate_rows], ignore_index=True)

    _save_task_artifacts("sales_csv", dirty, clean)

    config = TaskConfig(
        task_id="sales_csv",
        name="Sales CSV Cleanup",
        difficulty=TaskDifficulty.EASY,
        description="Remove duplicates and impute missing sales fields in a regional sales export.",
        objective="Repair null-heavy sales columns and remove duplicate rows while preserving valid records.",
        seed=seed,
        step_budget=10,
        target_score=0.9,
        dataset_rows=len(dirty),
        allowed_operations=[
            OperationName.FILL_NULLS,
            OperationName.DROP_DUPLICATES,
            OperationName.CAST_TYPE,
            OperationName.DROP_COLUMN,
        ],
        expected_issues=[
            "sales_rep contains missing values",
            "unit_price contains missing values",
            "dataset includes duplicate rows",
        ],
    )
    return GeneratedTask(config=config, dataframe=dirty, reference_tables={}, clean_dataframe=clean)


def build_patient_task() -> GeneratedTask:
    seed = 202
    rng = _rng(seed)
    row_count = 900

    clean = pd.DataFrame(
        {
            "patient_id": [f"P-{2000 + i}" for i in range(row_count)],
            "age": rng.integers(18, 90, size=row_count),
            "admission_date": pd.date_range("2025-01-01", periods=row_count, freq="D").astype(str),
            "discharge_delay_days": rng.integers(1, 15, size=row_count),
            "lab_result": rng.normal(98.0, 12.0, size=row_count).round(2),
        }
    )

    dirty = clean.copy(deep=True)
    dirty["age"] = dirty["age"].astype(str)
    dirty.loc[dirty.index % 11 == 0, "age"] = "unknown"

    alt_dates = pd.to_datetime(dirty["admission_date"])
    dirty.loc[dirty.index % 3 == 0, "admission_date"] = alt_dates.dt.strftime("%d/%m/%Y")
    dirty.loc[dirty.index % 5 == 0, "admission_date"] = alt_dates.dt.strftime("%m-%d-%Y")

    outlier_idx = rng.choice(row_count, size=45, replace=False)
    dirty.loc[outlier_idx, "lab_result"] = dirty.loc[outlier_idx, "lab_result"] * 5.5

    _save_task_artifacts("patient_records", dirty, clean)

    config = TaskConfig(
        task_id="patient_records",
        name="Patient Records Standardization",
        difficulty=TaskDifficulty.MEDIUM,
        description="Normalize patient table dtypes, parse inconsistent dates, and control lab-result outliers.",
        objective="Restore usable numeric and date fields while limiting unrealistic measurement spikes.",
        seed=seed,
        step_budget=18,
        target_score=0.88,
        dataset_rows=len(dirty),
        allowed_operations=[
            OperationName.FILL_NULLS,
            OperationName.CAST_TYPE,
            OperationName.CLIP_OUTLIERS,
            OperationName.PARSE_DATES,
            OperationName.APPLY_CONSTRAINT,
        ],
        expected_issues=[
            "age stored as text with invalid tokens",
            "admission_date uses mixed date formats",
            "lab_result contains outliers",
        ],
    )
    return GeneratedTask(config=config, dataframe=dirty, reference_tables={}, clean_dataframe=clean)


def build_ecommerce_task() -> GeneratedTask:
    seed = 303
    rng = _rng(seed)
    row_count = 1500

    customers = pd.DataFrame(
        {
            "customer_id": [f"C-{5000 + i}" for i in range(700)],
            "tier": rng.choice(["bronze", "silver", "gold"], size=700, p=[0.5, 0.35, 0.15]),
        }
    )

    clean = pd.DataFrame(
        {
            "order_id": [f"O-{90000 + i}" for i in range(row_count)],
            "customer_id": rng.choice(customers["customer_id"], size=row_count),
            "order_date": pd.date_range("2025-06-01", periods=row_count, freq="h").astype(str),
            "quantity": rng.integers(1, 8, size=row_count),
            "unit_price": rng.normal(75.0, 18.0, size=row_count).round(2),
            "status": rng.choice(["pending", "shipped", "delivered", "returned"], size=row_count),
        }
    )
    clean["total_amount"] = (clean["quantity"] * clean["unit_price"]).round(2)

    dirty = clean.copy(deep=True)
    dirty = dirty.rename(columns={"status": "order_status", "total_amount": "amount_total"})

    dirty.loc[rng.choice(row_count, size=120, replace=False), "customer_id"] = "UNKNOWN"
    dirty.loc[rng.choice(row_count, size=130, replace=False), "unit_price"] = np.nan
    dirty.loc[rng.choice(row_count, size=90, replace=False), "quantity"] = 0

    order_dates = pd.to_datetime(dirty["order_date"])
    dirty.loc[dirty.index % 4 == 0, "order_date"] = order_dates.dt.strftime("%d-%b-%Y %H:%M")
    dirty.loc[dirty.index % 7 == 0, "order_date"] = order_dates.dt.strftime("%Y/%m/%d %H:%M:%S")

    dupe_rows = dirty.sample(n=120, random_state=seed)
    dirty = pd.concat([dirty, dupe_rows], ignore_index=True)

    _save_task_artifacts(
        "ecommerce_orders",
        dirty,
        clean,
        reference_tables={"customers": customers},
    )

    config = TaskConfig(
        task_id="ecommerce_orders",
        name="E-commerce Orders Rehabilitation",
        difficulty=TaskDifficulty.HARD,
        description="Handle schema drift, missing values, referential integrity issues, duplicates, and invalid quantities.",
        objective="Bring an order export back to an analysis-ready state without sacrificing healthy data.",
        seed=seed,
        step_budget=25,
        target_score=0.9,
        dataset_rows=len(dirty),
        allowed_operations=[
            OperationName.FILL_NULLS,
            OperationName.DROP_DUPLICATES,
            OperationName.CAST_TYPE,
            OperationName.CLIP_OUTLIERS,
            OperationName.NORMALIZE,
            OperationName.RENAME_COLUMN,
            OperationName.PARSE_DATES,
            OperationName.APPLY_CONSTRAINT,
        ],
        expected_issues=[
            "schema drift on status and total columns",
            "customer_id violates customer reference table",
            "quantity contains invalid zero values",
            "order_date uses mixed formats",
            "dataset includes duplicates and missing prices",
        ],
    )
    return GeneratedTask(
        config=config,
        dataframe=dirty,
        reference_tables={"customers": customers},
        clean_dataframe=clean,
    )


def build_task_catalog() -> Dict[str, TaskFactory]:
    return {
        "sales_csv": build_sales_task,
        "patient_records": build_patient_task,
        "ecommerce_orders": build_ecommerce_task,
    }


def list_task_configs() -> List[TaskConfig]:
    return [factory().config for factory in build_task_catalog().values()]
