from __future__ import annotations

import json
import os
from pathlib import Path
from typing import List, Optional

from dotenv import load_dotenv
from ollama import Client

from data_cleaning_env import DataCleaningAction, DataCleaningEnv, OperationName

load_dotenv()

OLLAMA_BASE_URL = os.getenv("OLLAMA_BASE_URL") or os.getenv("API_BASE_URL", "http://localhost:11434")
MODEL_NAME = os.getenv("OLLAMA_MODEL") or os.getenv("MODEL_NAME", "llama3.1:8b")
BENCHMARK = "data_cleaning_pipeline"
TASKS = ["sales_csv", "patient_records", "ecommerce_orders"]
MAX_OUTPUT_TOKENS = 250
INFERENCE_OUTPUT_DIR = Path(os.getenv("INFERENCE_OUTPUT_DIR", "inference_outputs"))


SYSTEM_PROMPT = """
You are controlling a data-cleaning environment.
Choose the next best cleaning action from the supported operations and return JSON only.
Response schema:
{"op": "...", "column": "...", "params": {...}}
Prefer high-value deterministic repairs and avoid destructive actions.
""".strip()


def log_start(task: str, env: str, model: str) -> None:
    print(f"[START] task={task} env={env} model={model}", flush=True)


def log_step(step: int, action: str, reward: float, done: bool, error: Optional[str]) -> None:
    error_val = error if error else "null"
    print(
        f"[STEP] step={step} action={action} reward={reward:.2f} done={str(done).lower()} error={error_val}",
        flush=True,
    )


def log_end(success: bool, steps: int, score: float, rewards: List[float]) -> None:
    joined = ",".join(f"{reward:.2f}" for reward in rewards)
    print(
        f"[END] success={str(success).lower()} steps={steps} score={score:.3f} rewards={joined}",
        flush=True,
    )


def build_prompt(observation: dict) -> str:
    compact = {
        "task_name": observation["task_name"],
        "instructions": observation["instructions"],
        "issue_flags": observation["issue_flags"],
        "quality_score": observation["quality_score"],
        "steps_used": observation["steps_used"],
        "step_budget": observation["step_budget"],
        "column_stats": observation["column_stats"],
    }
    return json.dumps(compact, default=str)


def heuristic_action(task_id: str, observation: dict) -> DataCleaningAction:
    issues = " ".join(observation["issue_flags"]).lower()
    columns = {item["column"]: item for item in observation["column_stats"]}

    if "duplicate" in issues:
        return DataCleaningAction(op=OperationName.DROP_DUPLICATES, params={})

    if task_id == "sales_csv":
        if columns.get("unit_price", {}).get("null_fraction", 0) > 0:
            return DataCleaningAction(op=OperationName.FILL_NULLS, column="unit_price", params={"strategy": "median"})
        if columns.get("sales_rep", {}).get("null_fraction", 0) > 0:
            return DataCleaningAction(op=OperationName.FILL_NULLS, column="sales_rep", params={"strategy": "mode"})

    if task_id == "patient_records":
        if "mixed date" in issues or "parse cleanly" in issues:
            return DataCleaningAction(op=OperationName.PARSE_DATES, column="admission_date", params={})
        if columns.get("age", {}).get("dtype") not in {"int64", "Int64", "float64"}:
            return DataCleaningAction(op=OperationName.CAST_TYPE, column="age", params={"dtype": "int"})
        return DataCleaningAction(op=OperationName.CLIP_OUTLIERS, column="lab_result", params={"zmax": 3.0})

    if task_id == "ecommerce_orders":
        if "schema drift" in issues and "order_status" in columns:
            return DataCleaningAction(op=OperationName.RENAME_COLUMN, column="order_status", params={"new_name": "status"})
        if "schema drift" in issues and "amount_total" in columns:
            return DataCleaningAction(op=OperationName.RENAME_COLUMN, column="amount_total", params={"new_name": "total_amount"})
        if "duplicate" in issues:
            return DataCleaningAction(op=OperationName.DROP_DUPLICATES, params={})
        if columns.get("unit_price", {}).get("null_fraction", 0) > 0:
            return DataCleaningAction(op=OperationName.FILL_NULLS, column="unit_price", params={"strategy": "median"})
        if "non-positive values" in issues:
            return DataCleaningAction(op=OperationName.APPLY_CONSTRAINT, column="quantity", params={"rule": "positive"})
        if "customer_id" in columns:
            return DataCleaningAction(
                op=OperationName.APPLY_CONSTRAINT,
                column="customer_id",
                params={"rule": "reference_exists", "reference_table": "customers", "reference_column": "customer_id"},
            )
        return DataCleaningAction(op=OperationName.PARSE_DATES, column="order_date", params={})

    return DataCleaningAction(op=OperationName.DROP_DUPLICATES, params={})


def llm_action(client: Client, task_id: str, observation: dict) -> DataCleaningAction:
    try:
        response = client.chat(
            model=MODEL_NAME,
            messages=[
                {"role": "system", "content": SYSTEM_PROMPT},
                {"role": "user", "content": build_prompt(observation)},
            ],
            format="json",
            options={
                "temperature": 0.0,
                "num_predict": MAX_OUTPUT_TOKENS,
            },
        )
        payload = json.loads((response["message"]["content"] or "").strip() or "{}")
        return DataCleaningAction(**payload)
    except Exception:
        return heuristic_action(task_id, observation)


def run_task(task_id: str) -> float:
    env = DataCleaningEnv(task_id=task_id)
    client = Client(host=OLLAMA_BASE_URL)

    observation = env.reset(task_id=task_id)
    rewards: List[float] = []
    log_start(task=task_id, env=BENCHMARK, model=MODEL_NAME)

    try:
        while not observation.done and observation.steps_used < observation.step_budget:
            action = llm_action(client, task_id, observation.model_dump())
            observation = env.step(action)
            rewards.append(float(observation.reward or 0.0))
            log_step(
                step=observation.steps_used,
                action=f"{action.op.value}:{action.column}:{json.dumps(action.params, sort_keys=True)}",
                reward=float(observation.reward or 0.0),
                done=observation.done,
                error=observation.last_action_error,
            )
            if observation.done:
                break
    finally:
        env.save_episode_files(INFERENCE_OUTPUT_DIR / task_id)
        state = env.state
        score = state.quality_score
        success = score >= 0.85
        log_end(success=success, steps=state.step_count, score=score, rewards=rewards)
    return env.state.quality_score


def main() -> None:
    scores = {task_id: run_task(task_id) for task_id in TASKS}
    print(json.dumps({"benchmark": BENCHMARK, "scores": scores, "average_score": sum(scores.values()) / len(scores)}))


if __name__ == "__main__":
    main()
