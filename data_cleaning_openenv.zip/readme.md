# Data Cleaning Pipeline OpenEnv

`data_cleaning_pipeline` is a real-world OpenEnv environment for training and evaluating agents on tabular data cleaning. The environment simulates the kind of work analysts and data engineers do every day: fixing missing values, removing duplicates, repairing schema drift, parsing dates, clipping outliers, and restoring referential integrity.

## Motivation

Most agent benchmarks focus on browsing, code generation, or toy environments. This project targets a practical workflow that is both common and measurable: cleaning messy CSV exports under a limited step budget.

This environment is useful for:

- evaluating planning over multi-step structured tasks
- measuring whether agents choose safe, high-value data transformations
- testing reward shaping on realistic data-cleaning workflows
- benchmarking models on deterministic, reproducible tabular repair tasks

## Environment Summary

- Domain: tabular data cleaning
- API: OpenEnv `reset()`, `step()`, and `state`
- Observation type: OpenEnv `Observation`
- Action type: OpenEnv `Action`
- State type: OpenEnv `State`
- Reward range: `0.0` to `1.0`
- Difficulty tiers: easy, medium, hard

## Tasks

### 1. `sales_csv`

- Difficulty: easy
- Goal: remove duplicate rows and repair missing business fields
- Seeded issues:
  - missing `sales_rep`
  - missing `unit_price`
  - duplicated rows
- Step budget: `10`

### 2. `patient_records`

- Difficulty: medium
- Goal: standardize patient records into analysis-ready form
- Seeded issues:
  - `age` stored as text with invalid values
  - mixed `admission_date` formats
  - extreme outliers in `lab_result`
- Step budget: `18`

### 3. `ecommerce_orders`

- Difficulty: hard
- Goal: repair an order export with schema drift and integrity problems
- Seeded issues:
  - renamed columns (`order_status`, `amount_total`)
  - invalid `customer_id` foreign keys
  - missing `unit_price`
  - non-positive `quantity`
  - mixed `order_date` formats
  - duplicated rows
- Step budget: `25`

## Observation Space

Each observation contains:

- `task_id`
- `task_name`
- `instructions`
- `df_preview`
- `column_stats`
- `issue_flags`
- `quality_score`
- `steps_used`
- `step_budget`
- `last_action`
- `last_action_error`
- `reward`
- `done`

## Action Space

Supported operations:

- `fill_nulls`
- `drop_duplicates`
- `cast_type`
- `clip_outliers`
- `normalize`
- `rename_column`
- `drop_column`
- `parse_dates`
- `apply_constraint`

Example action:

```json
{
  "op": "fill_nulls",
  "column": "unit_price",
  "params": {
    "strategy": "median"
  }
}
```

## Reward Design

The reward function is shaped across the full trajectory:

- positive reward for improvement in `quality_score`
- no-op penalty when an action does not change the dataset
- data-loss penalty when too many rows are removed
- completion bonus when the target score is reached before the budget is exhausted

The final grader score remains in `[0.0, 1.0]`.

## Grading

Each task has a deterministic grader:

- `sales_csv`: null reduction plus duplicate removal
- `patient_records`: dtype repair, date parsing, and outlier reduction
- `ecommerce_orders`: schema repair, referential validity, duplicate removal, null repair, quantity validity, and date parsing

## Saved CSV Artifacts

Seeded datasets are written under [artifacts](/d:/PYTHON/RL/data_cleaning/artifacts) whenever tasks are generated.

For each task:

- `artifacts/<task_id>/raw.csv`: dirty starting dataset
- `artifacts/<task_id>/processed.csv`: cleaned target dataset
- `artifacts/<task_id>/reference_*.csv`: reference tables for constraint-based tasks

Examples:

- [artifacts/sales_csv/raw.csv](/d:/PYTHON/RL/data_cleaning/artifacts/sales_csv/raw.csv)
- [artifacts/sales_csv/processed.csv](/d:/PYTHON/RL/data_cleaning/artifacts/sales_csv/processed.csv)
- [artifacts/ecommerce_orders/reference_customers.csv](/d:/PYTHON/RL/data_cleaning/artifacts/ecommerce_orders/reference_customers.csv)

## Project Structure

```text
data_cleaning_env/
  __init__.py
  models.py
  tasks.py
  graders.py
  dataclean_env.py
server/
  app.py
inference.py
openenv.yaml
Dockerfile
pyproject.toml
requirements.txt
.env
artifacts/
```

## Setup

### Local Python setup

```powershell
python -m venv venv
.\venv\Scripts\Activate.ps1
python -m pip install -r requirements.txt
```

### Run the server

```powershell
python -m server.app
```

Or:

```powershell
uvicorn server.app:app --host 0.0.0.0 --port 7860 --reload
```

## OpenEnv Validation

Run:

```powershell
openenv validate
```

If validation reports a missing `uv.lock`, install `uv` and generate it:

```powershell
python -m pip install uv
uv lock
```

## Baseline Inference

Run the baseline:

```powershell
.\venv\Scripts\python.exe inference.py
```

The baseline uses the OpenAI Python client for all model calls. It supports both OpenAI-compatible endpoints and remote Ollama servers exposed through an OpenAI-compatible `/v1` API.

## Configuration via `.env`

The root [.env](/d:/PYTHON/RL/data_cleaning/.env) file is loaded automatically.

Example for a remote Ollama server:

```env
OLLAMA_BASE_URL=http://192.168.1.50:11434/v1
OLLAMA_MODEL=llama3.1:8b
OLLAMA_API_KEY=ollama
```

Example for an OpenAI-style endpoint:

```env
API_BASE_URL=https://router.huggingface.co/v1
MODEL_NAME=Qwen/Qwen2.5-72B-Instruct
HF_TOKEN=your_token_here
```

Supported configuration keys:

- `OLLAMA_BASE_URL`
- `OLLAMA_MODEL`
- `OLLAMA_API_KEY`
- `API_BASE_URL`
- `MODEL_NAME`
- `HF_TOKEN`
- `OPENAI_API_KEY`
- `API_KEY`

## HTTP Endpoints

When the server is running, the main endpoints are:

- `POST /reset`
- `POST /step`
- `GET /state`
- `GET /schema`
- `GET /metadata`
- `GET /health`
- `GET /docs`

## Docker

Build:

```powershell
docker build -t data-cleaning-openenv .
```

Run:

```powershell
docker run -p 7860:7860 data-cleaning-openenv
```

## Status

Implemented:

- deterministic seeded task generation
- typed OpenEnv action, observation, and state models
- shaped reward logic
- deterministic task graders
- OpenEnv server integration
- local baseline inference
- `.env`-driven model configuration
- raw and processed CSV artifact generation

Remaining deployment work may include final validator cleanup such as lockfile generation and Hugging Face Space packaging polish.
