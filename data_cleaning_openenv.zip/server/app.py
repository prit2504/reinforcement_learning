from __future__ import annotations

import uvicorn
from openenv.core import create_fastapi_app

from data_cleaning_env import DataCleaningAction, DataCleaningEnv, DataCleaningObservation

shared_env = DataCleaningEnv()
app = create_fastapi_app(lambda: shared_env, DataCleaningAction, DataCleaningObservation)


def main(host: str = "0.0.0.0", port: int = 7860) -> None:
    uvicorn.run(app, host=host, port=port)


if __name__ == "__main__":
    main()
