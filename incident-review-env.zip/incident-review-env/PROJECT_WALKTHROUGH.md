# incident-review-env Project Walkthrough

This file explains what the entire project does, how the pieces connect, and what each major function is responsible for.

## 1. What This Project Is

`incident-review-env` is a deterministic reinforcement learning environment for production incident response.

The project simulates a realistic on-call workflow:

1. Alerts fire for a production incident.
2. An agent inspects the alerts.
3. The agent optionally queries logs.
4. The agent proposes a root cause.
5. The agent applies a remediation command.
6. The agent writes a postmortem.
7. The environment grades that sequence with deterministic reward functions.

This is useful for evaluating whether an agent can perform structured incident management work without relying on hidden human grading.

## 2. End-to-End Flow

At a high level, the project runs like this:

1. A client calls `POST /reset`.
2. The FastAPI server creates or resets an `IncidentReviewEnv`.
3. The environment chooses one scenario such as database overload, bad deploy, memory leak, or latency spike.
4. The environment returns an observation containing alerts, logs, metrics, and task metadata.
5. A client sends actions to `POST /step`.
6. The environment updates internal state and recomputes reward.
7. The environment marks the episode done when the task requirements are satisfied or when max steps are reached.

The baseline client for this environment is `inference.py`.

## 3. Folder Structure

Here is what each important file or folder does.

### Top-level files

- `inference.py`
  Baseline agent loop. Calls the environment API, chooses actions, and prints `[START]`, `[STEP]`, and `[END]` markers.

- `README.md`
  Human-readable setup and usage guide.

- `requirements.txt`
  Python dependencies required for the environment and baseline client.

- `openenv.yaml`
  Runtime metadata for the OpenEnv-compatible deployment.

- `Dockerfile`
  Container build instructions for serving the FastAPI app.

- `test_smoke.py`
  Smoke tests that verify the API and a full inference run.

### `incident_env/`

- `server.py`
  FastAPI application and API endpoints.

- `env.py`
  Core environment logic, state management, action handling, reward computation, and done conditions.

- `models.py`
  Pydantic models for actions, rewards, observations, and environment state.

- `utils.py`
  Helper functions such as normalization, clamping, unsafe command detection, and deduplication.

### `incident_env/scenarios/`

Scenario definitions. Each file defines one incident type with:

- alerts
- logs
- metrics
- ground-truth labels
- root cause
- allowed remediation commands
- action items

Current scenarios:

- `db_overload.py`
- `memory_leak.py`
- `bad_deploy.py`
- `high_latency.py`

### `incident_env/graders/`

Deterministic grading functions:

- `triage_grader.py`
- `rca_grader.py`
- `postmortem_grader.py`

## 4. API Layer

The API lives in [incident_env/server.py](d:/RL/incident-review-env/incident_env/server.py).

### `ResetRequest`

This request model accepts:

- `task`
- `seed`
- `max_steps`

That means a client can control:

- which task type to run
- deterministic scenario selection through a seed
- maximum number of steps for the episode

### `app = FastAPI(...)`

Creates the FastAPI application.

### `ENV = IncidentReviewEnv()`

Creates the in-memory environment instance used by the server.

### `health()`

Route: `GET /health`

Returns:

```json
{"status": "ok"}
```

Used to check if the server is alive.

### `reset(request)`

Route: `POST /reset`

What it does:

1. Recreates the environment if `seed` or `max_steps` is provided.
2. Calls `ENV.reset(task=request.task)`.
3. Returns the first observation and reward.

This is the entry point for starting a new episode.

### `step(action)`

Route: `POST /step`

What it does:

1. Accepts a structured action.
2. Calls `ENV.step(action)`.
3. Returns the next observation, reward, done flag, and action info.

### `state()`

Route: `GET /state`

Returns a full snapshot of internal environment state, including:

- all logs
- current classifications
- hypothesis
- remediation history
- postmortem
- reward breakdown

This is mainly for debugging and inspection.

## 5. Data Models

The models live in [incident_env/models.py](d:/RL/incident-review-env/incident_env/models.py).

### `ActionType`

Allowed actions:

- `classify_alert`
- `query_logs`
- `set_hypothesis`
- `issue_remediation`
- `write_postmortem`

### `TaskType`

Supported tasks:

- `alert_triage`
- `root_cause`
- `full_resolution`

### `Action`

Represents one action from the client:

- `action_type`
- `payload`

### `Reward`

Stores reward components:

- `total`
- `triage`
- `rca`
- `postmortem`
- `efficiency`
- `penalty`

### `AlertRecord`

Represents one alert.

### `Observation`

This is what the agent sees after reset and each step.

Fields include:

- task
- step_count
- max_steps
- scenario metadata
- all alerts
- visible logs
- metrics
- active hypothesis
- remediation history
- partial scores
- hints
- degraded status

### `ResetResponse`, `StepResponse`, `EnvState`

These wrap the environment outputs in structured API responses.

## 6. Core Environment Logic

The main environment is implemented in [incident_env/env.py](d:/RL/incident-review-env/incident_env/env.py).

## 6.1 `IncidentReviewEnv.__init__`

Initializes:

- random generator
- step limit
- current scenario
- task
- classifications
- hypothesis
- postmortem
- remediation state
- visible logs
- metrics
- penalties
- done flag
- last reward

This function prepares the environment object but does not start an episode yet.

## 6.2 `reset(task=None)`

What it does:

1. Randomly chooses one scenario from `ALL_SCENARIOS`.
2. Sets the requested task or randomly chooses one.
3. Clears all internal episode state.
4. Starts with only the first two logs visible.
5. Copies scenario metrics.
6. Computes an initial reward.
7. Returns the first observation.

This is how an episode begins.

## 6.3 `step(action)`

This is the most important function in the environment.

What it does:

1. Verifies the environment was reset.
2. If already done, returns the current observation unchanged.
3. Increments `step_count`.
4. Finds an action handler based on `action.action_type`.
5. Executes that handler.
6. Recomputes reward.
7. Checks if the episode should be done.
8. Forces done if max steps are reached.
9. Returns:
   - next observation
   - reward
   - done
   - info

## 6.4 `state()`

Builds a full debug state using `EnvState`.

Includes internal details not always meant for the acting agent, such as:

- `all_logs`
- `scenario_root_cause`
- `ground_truth_alert_labels`

## 6.5 `_observation()`

Converts internal env state into the limited observation visible to the acting policy.

This is important because the agent does not get all hidden data directly.

## 6.6 `_compute_reward()`

This function combines the three graders plus efficiency:

- triage score from `grade_triage`
- RCA score from `grade_rca`
- postmortem score from `grade_postmortem`
- efficiency score from remaining steps

The current weighting is:

- triage: `0.30`
- rca: `0.30`
- postmortem: `0.30`
- efficiency: `0.10`

Then penalties are subtracted and the result is clamped into `[0.0, 1.0]`.

## 6.7 `_check_done()`

Done conditions depend on the task.

### `alert_triage`

Done when all alerts have been classified.

### `root_cause`

Done when:

- triage score is at least `0.7`
- RCA score is at least `0.5`

### `full_resolution`

Done when:

- remediation succeeded
- postmortem has been submitted

This is why a full-resolution episode should not end after remediation alone.

## 6.8 Action Handlers

Each supported action has its own handler.

### `_handle_classify_alert(payload)`

Checks:

- alert id is valid
- label is one of `symptom`, `cause`, `noise`

Then stores the classification.

### `_handle_query_logs(payload)`

Checks:

- keyword is present

Then:

1. Finds scenario logs containing the keyword.
2. Adds matching logs to `visible_logs`.
3. Slightly improves latency if the query matches scenario hints.

### `_handle_set_hypothesis(payload)`

Stores the proposed root cause string.

### `_handle_issue_remediation(payload)`

Checks:

- command is present

Then:

1. Stores the command in history.
2. Penalizes unsafe commands.
3. Marks success if the command matches one of the scenario’s accepted remediation commands.
4. Updates metrics accordingly.

### `_handle_write_postmortem(payload)`

Checks:

- timeline is a list
- action_items is a list

Then stores the postmortem fields.

## 7. Utility Functions

Helpers live in [incident_env/utils.py](d:/RL/incident-review-env/incident_env/utils.py).

### `clamp(value, lower=0.0, upper=1.0)`

Ensures values stay within bounds.

Used heavily in reward and metrics handling.

### `canonicalize(text)`

Lowercases and normalizes text.

Used for fuzzy matching and overlap comparisons.

### `token_set(text)`

Turns normalized text into a token set.

### `overlap_ratio(a, b)`

Computes token overlap ratio between two strings.

Used by RCA and postmortem graders.

### `contains_any(text, patterns)`

Checks if canonicalized text contains any canonicalized pattern.

### `is_unsafe_command(command)`

Returns whether a remediation command matches unsafe patterns like:

- `drop table`
- `rm -rf /`
- `truncate`

### `unique_preserve_order(values)`

Deduplicates while preserving original order.

Used when adding log lines to visible logs.

## 8. Graders

The graders are deterministic and do not rely on an LLM judge.

### `grade_triage`

File: [incident_env/graders/triage_grader.py](d:/RL/incident-review-env/incident_env/graders/triage_grader.py)

How it works:

1. Builds aligned `y_true` and `y_pred`.
2. Missing predictions are treated as `unclassified`.
3. Uses macro F1 over:
   - symptom
   - cause
   - noise

This rewards balanced classification quality across all alert types.

### `grade_rca`

File: [incident_env/graders/rca_grader.py](d:/RL/incident-review-env/incident_env/graders/rca_grader.py)

How it works:

1. Canonicalizes the prediction.
2. Compares it to the ground-truth root cause and aliases.
3. Returns:
   - `1.0` for exact or alias match
   - `0.5` for sufficient overlap
   - `0.0` otherwise

### `grade_postmortem`

File: [incident_env/graders/postmortem_grader.py](d:/RL/incident-review-env/incident_env/graders/postmortem_grader.py)

How it works:

1. Rewards a timeline with at least 3 items.
2. Rewards an impact section with enough detail.
3. Rewards at least 2 action items.
4. Rewards RCA overlap with the true root cause.

Then clamps the total score.

## 9. Scenarios

Scenarios are defined with a common dataclass in [incident_env/scenarios/base.py](d:/RL/incident-review-env/incident_env/scenarios/base.py).

Each scenario contains:

- `scenario_id`
- `title`
- `service`
- `summary`
- `alerts`
- `logs`
- `metrics`
- `root_cause`
- `aliases`
- `ground_truth_alert_labels`
- `remediation_commands`
- `timeline_reference`
- `impact`
- `action_items`
- `log_hints`

These files are effectively the dataset for the environment.

### `db_overload.py`

Simulates database saturation caused by analytics backfill.

### `memory_leak.py`

Simulates memory leak and OOM behavior in recommendation service.

### `bad_deploy.py`

Simulates authentication failure after a bad certificate/config deployment.

### `high_latency.py`

Simulates retry storm and dependency latency in payments flow.

## 10. Baseline Agent: `inference.py`

This file is the reference client that runs a policy loop against the environment API.

It can operate in two modes:

1. Model-backed mode using your Ollama-compatible endpoint.
2. Heuristic fallback mode when the model is unavailable or returns unusable actions.

## 10.1 Configuration

Important config values:

- `DEFAULT_ENV_URL`
- `API_BASE_URL`
- `MODEL_NAME`
- `MAX_STEPS`
- `MODEL_TIMEOUT`
- `SUCCESS_THRESHOLD`

### Meaning

- `DEFAULT_ENV_URL`
  Where the environment server is running.

- `API_BASE_URL`
  Where your Ollama-compatible model endpoint is running.

- `MAX_STEPS`
  Client-side loop bound and now also forwarded to the environment on `/reset`.

## 10.2 Text Heuristic Helpers

### `canonicalize(text)`

Normalizes free text for keyword matching.

### `classify_alert_from_text(alert)`

Uses alert message text and severity to classify alerts as:

- noise
- cause
- symptom

### `rank_alert(alert)`

Ranks alerts so the heuristic policy chooses more informative alerts first.

### `infer_root_cause(observation)`

Builds one text blob from visible logs and alert messages, then matches it against root-cause patterns.

### `infer_remediation(observation)`

Uses hypothesis, visible logs, and alerts to choose a likely remediation command.

### `build_postmortem(observation)`

Builds a generic but valid postmortem payload from current observation state.

## 10.3 Model Interaction

### `build_client()`

Returns the normalized model backend URL, or `None` if not configured.

### `call_model(client, observation)`

Builds a prompt and calls:

`POST {API_BASE_URL}/api/chat`

Expected model behavior:

- return one strict JSON object
- include `action_type`
- include `payload`

If the model does not comply, later code falls back to the heuristic path.

### `normalize_action(action, observation)`

Validates and canonicalizes the model output into the exact action schema expected by the environment.

This protects the environment from malformed model output.

## 10.4 Heuristic Policy

### `heuristic_action(observation, classified_ids, previous_actions)`

This is the generic fallback policy.

What it does:

1. Picks a few informative alerts to classify first.
2. If logs have not been expanded yet, queries logs using inferred keywords.
3. If no hypothesis exists, infers one from alerts/logs.
4. If in full resolution and no remediation exists, infers a remediation.
5. If remediation exists, writes a postmortem.
6. Avoids repeating log keywords already used.

## 10.5 Stagnation Detection

### `is_stagnant_action(action, previous_actions)`

Detects repeated actions such as:

- same hypothesis again
- same alert classified again
- same log query again
- same remediation again
- repeated postmortem submission

This is important because model outputs can loop.

## 10.6 Action Selection

### `select_action(client, observation, previous_actions, classified_ids)`

Logic:

1. Try the model.
2. Normalize the model output.
3. If the model output is stagnant, switch to the heuristic action.
4. If the model call fails entirely, switch to heuristic action.

This makes the baseline robust even when the model behaves poorly.

## 10.7 Main Loop

### `main()`

This is the execution entry point.

What it does:

1. Builds the model client.
2. Calls `/reset` with:
   - `task="full_resolution"`
   - `max_steps=MAX_STEPS`
3. Prints `[START]`.
4. Repeats up to `MAX_STEPS`:
   - chooses an action
   - sends it to `/step`
   - prints `[STEP]`
   - breaks if `done=True`
5. Prints `[END]` with:
   - success
   - steps
   - score
   - reward history

## 11. Smoke Tests

The tests live in [test_smoke.py](d:/RL/incident-review-env/test_smoke.py).

### `test_health_reset_step_and_state`

Verifies:

- `/health`
- `/reset`
- `/step`
- `/state`

### `test_reset_accepts_custom_max_steps`

Verifies that `max_steps` passed to `/reset` is respected.

### `test_inference_heuristic_run_completes`

Runs `inference.main()` using a mocked in-process API instead of a live server.

This confirms that the baseline loop can complete end to end.

### `test_heuristic_does_not_repeat_same_log_query_forever`

Regression test for the repeated `query_logs` bug.

## 12. How To Run The Project

### Start the server

```powershell
uvicorn incident_env.server:app --host 0.0.0.0 --port 7860
```

### Run inference

If using your remote Ollama-compatible backend:

```powershell
python inference.py
```

If forcing heuristic-only mode:

```powershell
$env:API_BASE_URL=""
python inference.py
```

### Run smoke tests

```powershell
python -m unittest test_smoke.py -v
```

## 13. What “Working Properly” Means For This Project

The project is working properly when:

- `/health` returns success
- `/reset` returns a valid observation
- `/step` updates state and reward correctly
- `full_resolution` requires remediation plus postmortem before done
- the baseline does not get stuck in repeated action loops
- `max_steps` is consistent between the client and the environment
- smoke tests pass

## 14. Current Final Status

At the current state of the project:

- FastAPI server works
- scenario registry works
- reward logic works
- deterministic graders work
- `inference.py` works with both model-backed and heuristic fallback behavior
- repeated log-query looping has been fixed
- `max_steps` is now wired through reset properly
- smoke tests pass

The only remaining non-blocking cleanup is checked-in `__pycache__` files, which are repo noise but do not break runtime behavior.
