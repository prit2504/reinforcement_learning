# incident-review-env

## Problem Description

`incident-review-env` is an OpenEnv-compatible reinforcement learning environment for production incident management. It simulates realistic SRE workflows where an agent must triage noisy alerts, inspect evidence, diagnose the root cause, apply a safe remediation, and write a postmortem that captures impact and follow-up actions.

## Why It Matters

Modern incident response is one of the highest-leverage operational tasks in software systems. Training agents against structured, reproducible incident workflows helps teams evaluate whether an AI system can safely support on-call engineers without depending on non-deterministic graders or hidden human judgment.

## Architecture Diagram

```text
+-------------------+        +--------------------+        +-------------------+
| OpenEnv Client    | -----> | FastAPI Server     | -----> | IncidentReviewEnv |
| /reset /step      |        | incident_env.server|        | reset/step/state  |
+-------------------+        +--------------------+        +-------------------+
                                                                  |
                                                                  v
                 +----------------------+   +-------------------+   +----------------------+
                 | Scenario Registry    |   | Deterministic     |   | Reward Aggregation   |
                 | db/memory/deploy/... |   | Graders           |   | triage + RCA + PM    |
                 +----------------------+   +-------------------+   +----------------------+
```

## Action Design

Each action uses a typed payload:

- `classify_alert` with `{id, label}`
- `query_logs` with `{keyword}`
- `set_hypothesis` with `{cause}`
- `issue_remediation` with `{command}`
- `write_postmortem` with `{timeline, impact, rca, action_items}`

Unsafe commands such as destructive deletion incur a deterministic penalty and worsen environment metrics.

## Observation Design

Each observation returns:

- task metadata and step counters
- full alert set for the active scenario
- currently visible logs
- live metrics: `cpu`, `latency`, `memory`
- current hypothesis
- remediation history
- postmortem submission state
- partial score breakdown
- task hints

## Tasks

- `alert_triage` (easy): classify alerts into `symptom`, `cause`, or `noise`
- `root_cause` (medium): classify evidence and identify the most likely root cause
- `full_resolution` (hard): complete triage, remediate the incident, and write a valid postmortem

## Reward Logic

Rewards are continuous and normalized into `[0.0, 1.0]`.

- triage F1 score: `0.3`
- RCA accuracy: `0.3`
- postmortem quality: `0.3`
- efficiency: `0.1`

Task-specific shaping uses these same components with weights adjusted for the required scope of the task. In full resolution mode, successful remediation grants recovery progress before clipping to `[0, 1]`.

Penalties:

- unsafe remediation command: `-0.1`
- environment degradation: increases latency, memory, and CPU stress

## Setup Instructions

Linux/macOS:

```bash
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
uvicorn incident_env.server:app --host 0.0.0.0 --port 7860
```

Windows PowerShell:

```powershell
python -m venv .venv
.venv\Scripts\Activate.ps1
pip install -r requirements.txt
uvicorn incident_env.server:app --host 0.0.0.0 --port 7860
```

Docker:

```bash
docker build -t incident-review-env .
docker run -p 7860:7860 incident-review-env
```

## Example Run

```bash
curl -X POST http://localhost:7860/reset -H "content-type: application/json" -d "{\"task\":\"root_cause\"}"
curl -X POST http://localhost:7860/step -H "content-type: application/json" -d "{\"action_type\":\"query_logs\",\"payload\":{\"keyword\":\"deploy\"}}"
curl -X POST http://localhost:7860/step -H "content-type: application/json" -d "{\"action_type\":\"set_hypothesis\",\"payload\":{\"cause\":\"bad auth-service deploy shipped invalid certificate bundle configuration\"}}"
curl http://localhost:7860/state
```

## Inference Baseline

`inference.py` runs a bounded policy loop against the environment API and prints the required hackathon validation markers:

- `[START]`
- `[STEP]`
- `[END]`

By default it tries an Ollama-compatible chat endpoint at `http://127.0.0.1:11434/api/chat` using `llama3.1:8b`.
If no model backend is available, it still runs by falling back to the built-in heuristic policy.

Useful environment variables:

- `ENV_BASE_URL` for the environment server, default `http://127.0.0.1:7860`
- `API_BASE_URL` for the model backend, default `http://127.0.0.1:11434`
- `MODEL_NAME` for the chat model, default `llama3.1:8b`
- `MODEL_TIMEOUT` for each model call in seconds, default `15`
- `SUCCESS_THRESHOLD` for the baseline completion target, default `0.6`
- `RUN_SEED` for deterministic scenario selection in `inference.py`, default `42`

`MAX_STEPS` in `inference.py` is also forwarded to `/reset`, so the environment and the client loop stay aligned.

Example baseline runs:

Heuristic only:

```powershell
$env:API_BASE_URL=""
python inference.py
```

With Ollama running locally:

```powershell
ollama serve
python inference.py
```

To intentionally change the scenario while keeping runs reproducible:

```powershell
$env:RUN_SEED="7"
python inference.py
```

## Smoke Tests

Run the built-in smoke tests with:

```powershell
python -m unittest test_smoke.py -v
```

This validates:

- FastAPI health, reset, step, and state endpoints
- a full heuristic `inference.py` run without requiring a live model backend
