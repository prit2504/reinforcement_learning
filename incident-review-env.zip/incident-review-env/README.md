# incident-review-env

## Problem Description

`incident-review-env` is an OpenEnv-compatible reinforcement learning environment for production incident management. It simulates realistic SRE workflows where an agent must triage noisy alerts, inspect evidence, diagnose the root cause, apply a safe remediation, and write a postmortem that captures impact and follow-up actions.

## Why It Matters

Modern incident response is one of the highest-leverage operational tasks in software systems. Training agents against structured, reproducible incident workflows helps teams evaluate whether an AI system can safely support on-call engineers without depending on non-deterministic graders or hidden human judgment.

## Architecture Diagram

```text
+-------------------+        +--------------------+        +-------------------+
| OpenEnv Client    | -----> | FastAPI Server     | -----> | IncidentReviewEnv |
| /reset /step      |        | incident_env.server|        | reset/step/state  |
+-------------------+        +--------------------+        +-------------------+
                                                                  |
                                                                  v
                 +----------------------+   +-------------------+   +----------------------+
                 | Scenario Registry    |   | Deterministic     |   | Reward Aggregation   |
                 | db/memory/deploy/... |   | Graders           |   | triage + RCA + PM    |
                 +----------------------+   +-------------------+   +----------------------+
```

## Action Design

Each action uses a typed payload:

- `classify_alert` with `{id, label}`
- `query_logs` with `{keyword}`
- `set_hypothesis` with `{cause}`
- `issue_remediation` with `{command}`
- `write_postmortem` with `{timeline, impact, rca, action_items}`

Unsafe commands such as destructive deletion incur a deterministic penalty and worsen environment metrics.

## Observation Design

Each observation returns:

- task metadata and step counters
- full alert set for the active scenario
- currently visible logs
- live metrics: `cpu`, `latency`, `memory`
- current hypothesis
- remediation history
- postmortem submission state
- partial score breakdown
- task hints

## Tasks

- `alert_triage` (easy): classify alerts into `symptom`, `cause`, or `noise`
- `root_cause` (medium): classify evidence and identify the most likely root cause
- `full_resolution` (hard): complete triage, remediate the incident, and write a valid postmortem

## Reward Logic

Rewards are continuous and normalized into `[0.0, 1.0]`.

- triage F1 score: `0.3`
- RCA accuracy: `0.3`
- postmortem quality: `0.3`
- efficiency: `0.1`

Task-specific shaping uses these same components with weights adjusted for the required scope of the task. In full resolution mode, successful remediation grants recovery progress before clipping to `[0, 1]`.

Penalties:

- unsafe remediation command: `-0.1`
- environment degradation: increases latency, memory, and CPU stress

## Setup Instructions

```bash
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
uvicorn incident_env.server:app --host 0.0.0.0 --port 7860
```

Docker:

```bash
docker build -t incident-review-env .
docker run -p 7860:7860 incident-review-env
```

## Example Run

```bash
curl -X POST http://localhost:7860/reset -H "content-type: application/json" -d "{\"task\":\"root_cause\"}"
curl -X POST http://localhost:7860/step -H "content-type: application/json" -d "{\"action_type\":\"query_logs\",\"payload\":{\"keyword\":\"deploy\"}}"
curl -X POST http://localhost:7860/step -H "content-type: application/json" -d "{\"action_type\":\"set_hypothesis\",\"payload\":{\"cause\":\"bad auth-service deploy shipped invalid certificate bundle configuration\"}}"
curl http://localhost:7860/state
```

## Inference Baseline

`inference.py` runs a bounded 8-step policy loop against the environment API and uses an OpenAI-compatible client to choose structured actions. It prints the required hackathon validation markers:

- `[START]`
- `[STEP]`
- `[END]`
