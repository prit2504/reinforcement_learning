# incident-review-env Detailed README

## Project Summary

`incident-review-env` is a deterministic incident-response reinforcement learning environment. It is built to evaluate whether an agent can investigate and resolve realistic SRE-style incidents using structured actions instead of free-form chat.

The project models the full operational loop:

1. receive alerts
2. separate symptoms from actual causes
3. inspect logs
4. decide the root cause
5. choose a safe remediation
6. write a postmortem
7. receive a reward based on how well the response was handled

The baseline client for this environment is `inference.py`, which calls the FastAPI API and performs the workflow step by step.

## What This Project Actually Contains

### 1. Environment API

The API is implemented in `incident_env/server.py`.

It exposes four routes:

- `GET /health`
- `POST /reset`
- `POST /step`
- `GET /state`

This is the entry point used by `inference.py` and any other external client.

### 2. Environment Engine

The environment logic is implemented in `incident_env/env.py`.

This file is responsible for:

- choosing a scenario
- maintaining episode state
- handling actions
- updating visible logs and metrics
- calculating reward
- deciding when the task is finished

### 3. Scenario Dataset

The incident data lives in `incident_env/scenarios/`.

Current scenarios:

- `db_overload.py`
- `memory_leak.py`
- `bad_deploy.py`
- `high_latency.py`

Each scenario contains:

- a title
- a service
- a summary
- many alerts
- logs
- metrics
- the true root cause
- acceptable remediation commands
- impact text
- expected action items

### 4. Graders

The deterministic reward components live in `incident_env/graders/`.

They grade:

- alert triage
- root-cause identification
- postmortem quality

### 5. Baseline Agent

The acting baseline is in `inference.py`.

It:

- resets the environment
- receives an observation
- chooses actions
- sends them to `/step`
- prints progress as `[START]`, `[STEP]`, `[END]`

### 6. Tests

The tests are in `test_smoke.py`.

They verify:

- API correctness
- inference completion
- custom max-step behavior
- repeated-query regression handling
- deterministic seeded reset behavior

## Project Architecture

```text
+----------------------+
| inference.py         |
| baseline agent       |
+----------+-----------+
           |
           v
+----------------------+
| FastAPI server       |
| incident_env.server  |
| /reset /step /state  |
+----------+-----------+
           |
           v
+----------------------+
| IncidentReviewEnv    |
| incident_env.env     |
| state + reward logic |
+----+-------------+---+
     |             |
     v             v
+---------+   +------------+
| scenarios|   | graders   |
| data     |   | scoring   |
+---------+   +------------+
```

## End-to-End Flow

This is the actual runtime flow of the project.

### Step 1. Start the server

You run:

```powershell
uvicorn incident_env.server:app --host 0.0.0.0 --port 7860
```

The FastAPI app becomes available.

### Step 2. Run `inference.py`

You run:

```powershell
python inference.py
```

`inference.py` uses:

- `ENV_BASE_URL`
- `API_BASE_URL`
- `MODEL_NAME`
- `MAX_STEPS`
- `RUN_SEED`
- `SUCCESS_THRESHOLD`

### Step 3. `inference.py` calls `/reset`

It sends:

- `task="full_resolution"`
- `max_steps`
- `seed`

The server forwards this into `IncidentReviewEnv`.

### Step 4. Environment loads a scenario

The environment resets its internal state:

- clears classifications
- clears hypothesis
- clears remediation history
- clears postmortem
- restores initial metrics
- exposes only the first few logs

Then it returns the first observation.

### Step 5. Agent selects actions

For each loop iteration:

1. try model-backed action selection
2. normalize action shape
3. reject malformed or stagnant actions
4. fall back to heuristic policy if needed

### Step 6. Action goes to `/step`

The environment executes the action, updates state, recalculates reward, and returns:

- updated observation
- reward
- `done`
- `info`

### Step 7. Episode ends

The loop stops when:

- `done=True`, or
- `max_steps` reached

For `full_resolution`, `done=True` requires:

- successful remediation
- submitted postmortem

## Tasks

The environment supports these tasks:

### `alert_triage`

Goal:

- classify all alerts into `symptom`, `cause`, or `noise`

### `root_cause`

Goal:

- perform enough triage
- identify a plausible root cause

### `full_resolution`

Goal:

- classify meaningful alerts
- identify the root cause
- apply remediation
- submit postmortem

Your baseline currently uses `full_resolution`.

## Observation Design

Each observation contains:

- `task`
- `step_count`
- `max_steps`
- `scenario_id`
- `scenario_title`
- `alerts`
- `visible_logs`
- `metrics`
- `active_hypothesis`
- `remediation_history`
- `postmortem_submitted`
- `partial_scores`
- `hints`
- `degraded`

### Why this matters

This observation is the full working context for the acting agent. The agent is not directly given hidden ground truth like the exact root cause or the ground-truth alert labels.

## Action Design

The environment accepts these actions.

### `classify_alert`

Example payload:

```json
{"id": "A21", "label": "symptom"}
```

Purpose:

- classify one alert

### `query_logs`

Example payload:

```json
{"keyword": "backfill"}
```

Purpose:

- reveal more logs matching the keyword

### `set_hypothesis`

Example payload:

```json
{"cause": "unbounded analytics backfill saturating the primary postgres database"}
```

Purpose:

- store the agent’s RCA hypothesis

### `issue_remediation`

Example payload:

```json
{"command": "pause analytics backfill"}
```

Purpose:

- apply the chosen remediation command

### `write_postmortem`

Example payload:

```json
{
  "timeline": ["...", "...", "..."],
  "impact": "...",
  "rca": "...",
  "action_items": ["...", "..."]
}
```

Purpose:

- submit the final incident write-up

## Reward Logic

Reward is computed in `incident_env/env.py`.

### Formula

```text
total =
  0.30 * triage_score +
  0.30 * rca_score +
  0.30 * postmortem_score +
  0.10 * efficiency_score
```

Then:

- penalties are subtracted
- the result is clamped to `[0.0, 1.0]`

### Reward components

#### Triage

Computed by `grade_triage()`.

This checks how well the agent classifies alerts into:

- symptom
- cause
- noise

#### RCA

Computed by `grade_rca()`.

This compares the hypothesis to:

- the exact root cause
- known aliases
- fuzzy token overlap

#### Postmortem

Computed by `grade_postmortem()`.

This checks:

- timeline quality
- impact detail
- action items
- RCA quality in the postmortem

#### Efficiency

This rewards using fewer steps.

## Why Scores Are Around 0.75

Your baseline now finishes successfully and usually lands around `0.74` to `0.75`.

That happens because:

- triage is strong but not perfect
- RCA is usually correct
- remediation is usually correct
- postmortem is valid
- efficiency is decent but not maximal

The baseline is solving the task reliably, but it is not classifying every alert in the scenario, so the triage component is not close to 1.0.

## Inference Pipeline in `inference.py`

This is the actual logic used by the baseline client.

### Configuration

`inference.py` reads:

- `DEFAULT_ENV_URL`
- `API_BASE_URL`
- `MODEL_NAME`
- `MAX_STEPS`
- `MODEL_TIMEOUT`
- `SUCCESS_THRESHOLD`
- `RUN_SEED`

### Reset

It sends a reset request with:

- `task="full_resolution"`
- `max_steps=MAX_STEPS`
- `seed=RUN_SEED`

That makes runs deterministic by default.

### Model path

`call_model()` sends the observation to your Ollama-compatible endpoint:

- backend: `http://nav0357:19434`
- route: `/api/chat`

The model is expected to return exactly one JSON action.

### Normalization

`normalize_action()` checks:

- action type
- payload structure
- valid labels
- valid alert ids
- valid strings/lists where required

### Stagnation protection

`is_stagnant_action()` blocks repeated:

- alert classifications
- log queries
- hypotheses
- remediation commands
- postmortems

This prevents loops.

### Heuristic fallback

If the model fails or gives a stagnant action, the fallback policy runs.

Current fallback strategy:

1. classify a balanced set of alerts across `cause`, `symptom`, and `noise`
2. infer RCA from alerts and logs
3. infer remediation
4. write postmortem

## Actual Input and Output

The system does not take one plain text question as input. The real input is a structured observation returned by the environment API.

### Actual input to the system

When `inference.py` calls `/reset` or `/step`, the server returns an observation like this:

```json
{
  "task": "full_resolution",
  "step_count": 0,
  "max_steps": 10,
  "scenario_id": "db_overload",
  "scenario_title": "Primary Database Saturation",
  "alerts": [
    {
      "id": "A01",
      "source": "prometheus",
      "service": "orders-api",
      "severity": "critical",
      "message": "Checkout p95 latency exceeded 2.8s",
      "timestamp": "2026-04-06T10:00:00Z"
    },
    {
      "id": "A04",
      "source": "prometheus",
      "service": "orders-db",
      "severity": "warning",
      "message": "Long running query count above 40",
      "timestamp": "2026-04-06T10:00:30Z"
    }
  ],
  "visible_logs": [
    "2026-04-06T10:00:11Z orders-db postgres[4421]: LOG duration=18450ms statement=SELECT * FROM order_events ...",
    "2026-04-06T10:00:28Z analytics-worker backfill[71]: started tenant-wide revenue backfill without LIMIT clause"
  ],
  "metrics": {
    "cpu": 97.0,
    "latency": 2860.0,
    "memory": 78.0
  },
  "active_hypothesis": null,
  "remediation_history": [],
  "postmortem_submitted": false,
  "partial_scores": {
    "triage": 0.0,
    "rca": 0.0,
    "postmortem": 0.0,
    "efficiency": 1.0
  },
  "hints": [
    "Complete triage, identify root cause, remediate safely, and submit a postmortem."
  ],
  "degraded": false
}
```

This observation is what the system uses to infer:

- which alerts are symptoms
- which alerts are causes
- which alerts are noise
- what logs matter
- what the likely root cause is
- what remediation command to choose
- what to write in the postmortem

If model-backed inference is enabled, this observation is embedded into the model prompt.

If the model gives a bad or repetitive response, the fallback heuristic uses this same observation directly.

### Actual output from the system

The output is a sequence of structured actions plus the final reward summary.

For example, from a database overload observation, the system may produce:

```json
{"action_type": "classify_alert", "payload": {"id": "A21", "label": "symptom"}}
```

then:

```json
{"action_type": "set_hypothesis", "payload": {"cause": "unbounded analytics backfill saturating the primary postgres database"}}
```

then:

```json
{"action_type": "issue_remediation", "payload": {"command": "pause analytics backfill"}}
```

then:

```json
{
  "action_type": "write_postmortem",
  "payload": {
    "timeline": [
      "Automated alerts fired and the incident was acknowledged by the on-call responder.",
      "Logs, metrics, and alert signals were reviewed to narrow the issue to the most likely root cause.",
      "Mitigation was applied: pause analytics backfill."
    ],
    "impact": "Customers experienced elevated failures or latency in analytics-worker, auth-service, checkout until the incident was mitigated. The responder used the available evidence to reduce risk and restore service health.",
    "rca": "unbounded analytics backfill saturating the primary postgres database",
    "action_items": [
      "Add stronger pre-deployment safety checks for production-impacting changes.",
      "Improve alert-to-remediation guardrails so similar incidents recover faster."
    ]
  }
}
```

And the final printed output looks like:

```text
[END] success=True steps=9 score=0.7479 rewards=[...]
```

So the true system input is the environment observation, and the true system output is the sequence of actions plus the final scored episode result.

## Actual File Responsibilities

### `incident_env/server.py`

Handles API requests and environment lifecycle.

### `incident_env/env.py`

Implements:

- reset
- step
- reward
- done conditions
- action handlers

### `incident_env/models.py`

Defines all Pydantic models used by the API and env.

### `incident_env/utils.py`

Provides helpers:

- `clamp`
- `canonicalize`
- `overlap_ratio`
- `contains_any`
- `is_unsafe_command`
- `unique_preserve_order`

### `incident_env/scenarios/*.py`

Each file defines one fully specified incident scenario.

### `incident_env/graders/*.py`

Each file defines one deterministic scoring function.

### `test_smoke.py`

Verifies the system works end to end.

## Example Working Output

This is a valid deterministic run from your current project:

```text
(.venv) D:\RL\incident-review-env>python inference.py
[START] task=full_resolution env=incident-review-env model=llama3.1:8b backend=http://nav0357:19434 seed=42
[STEP] step=1 action={"action_type": "classify_alert", "payload": {"id": "A21", "label": "symptom"}} reward=0.1067 done=False error=None
[STEP] step=2 action={"action_type": "classify_alert", "payload": {"id": "A04", "label": "cause"}} reward=0.1300 done=False error=None
[STEP] step=3 action={"action_type": "classify_alert", "payload": {"id": "A11", "label": "noise"}} reward=0.1486 done=False error=None
[STEP] step=4 action={"action_type": "classify_alert", "payload": {"id": "A07", "label": "cause"}} reward=0.1624 done=False error=None
[STEP] step=5 action={"action_type": "classify_alert", "payload": {"id": "A01", "label": "symptom"}} reward=0.1665 done=False error=None
[STEP] step=6 action={"action_type": "classify_alert", "payload": {"id": "A12", "label": "noise"}} reward=0.1779 done=False error=None
[STEP] step=7 action={"action_type": "set_hypothesis", "payload": {"cause": "unbounded analytics backfill saturating the primary postgres database"}} reward=0.4679 done=False error=None
[STEP] step=8 action={"action_type": "issue_remediation", "payload": {"command": "pause analytics backfill"}} reward=0.4579 done=False error=None
[STEP] step=9 action={"action_type": "write_postmortem", "payload": {"timeline": ["Automated alerts fired and the incident was acknowledged by the on-call responder.", "Logs, metrics, and alert signals were reviewed to narrow the issue to the most likely root cause.", "Mitigation was applied: pause analytics backfill."], "impact": "Customers experienced elevated failures or latency in analytics-worker, auth-service, checkout until the incident was mitigated. The responder used the available evidence to reduce risk and restore service health.", "rca": "unbounded analytics backfill saturating the primary postgres database", "action_items": ["Add stronger pre-deployment safety checks for production-impacting changes.", "Improve alert-to-remediation guardrails so similar incidents recover faster."]}} reward=0.7479 done=True error=None
[END] success=True steps=9 score=0.7479 rewards=[0.1, 0.10666666666666667, 0.13, 0.14857142857142858, 0.16238095238095235, 0.16648351648351645, 0.1779120879120879, 0.46791208791208794, 0.45791208791208793, 0.747912087912088]
```

## Interpretation of the Output

This output means:

- the server and client are connected correctly
- the seeded run is deterministic
- the agent classified alerts first
- the hypothesis matched the database overload scenario
- the remediation was accepted
- the postmortem was accepted
- the task completed successfully
- the baseline achieved a solid final score

## Run Instructions

### Start the server

```powershell
uvicorn incident_env.server:app --host 0.0.0.0 --port 7860
```

### Run inference

```powershell
python inference.py
```

### Run tests

```powershell
python -m unittest test_smoke.py -v
```

## Final Project Status

The project is now ready in a stable working state:

- environment API is working
- reward logic is deterministic
- action handlers are working
- seeded inference runs are deterministic
- scenario variation can still be requested by changing `RUN_SEED`
- repeated-action loops were fixed
- max-step handling is aligned between client and server
- smoke tests pass

This makes the project suitable for demonstration, evaluation, and future improvement.
