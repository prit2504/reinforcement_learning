from __future__ import annotations

from typing import Any, Dict, Iterable

from incident_env.utils import clamp, overlap_ratio


def grade_postmortem(postmortem: Dict[str, Any] | None, root_cause: str, action_items: Iterable[str]) -> float:
    if not postmortem:
        return 0.0

    timeline = postmortem.get("timeline") or []
    impact = str(postmortem.get("impact") or "")
    rca = str(postmortem.get("rca") or "")
    submitted_items = postmortem.get("action_items") or []

    score = 0.0
    if isinstance(timeline, list) and len(timeline) >= 3:
        score += 0.34
    if len(impact.strip()) > 50:
        score += 0.33
    if isinstance(submitted_items, list) and len(submitted_items) >= 2:
        score += 0.23

    if overlap_ratio(rca, root_cause) >= 0.35:
        score += 0.10
    elif any(overlap_ratio(rca, item) >= 0.20 for item in action_items):
        score += 0.05

    return clamp(score)
