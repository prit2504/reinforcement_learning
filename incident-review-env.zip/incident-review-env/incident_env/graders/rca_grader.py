from __future__ import annotations

from typing import Iterable

from incident_env.utils import canonicalize, overlap_ratio


def grade_rca(prediction: str | None, root_cause: str, aliases: Iterable[str]) -> float:
    if not prediction:
        return 0.0

    guess = canonicalize(prediction)
    candidates = [canonicalize(root_cause), *[canonicalize(alias) for alias in aliases]]
    if guess in candidates:
        return 1.0

    best_overlap = max(overlap_ratio(guess, candidate) for candidate in candidates)
    if best_overlap >= 0.4:
        return 0.5
    return 0.0
