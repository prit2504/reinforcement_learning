from __future__ import annotations

from typing import Dict

from sklearn.metrics import f1_score


LABELS = ["symptom", "cause", "noise", "unclassified"]


def grade_triage(ground_truth: Dict[str, str], predictions: Dict[str, str]) -> float:
    if not ground_truth:
        return 0.0

    y_true = []
    y_pred = []
    for alert_id, label in sorted(ground_truth.items()):
        y_true.append(label)
        y_pred.append(predictions.get(alert_id, "unclassified"))

    score = f1_score(y_true, y_pred, labels=LABELS[:-1], average="macro", zero_division=0)
    return float(max(0.0, min(1.0, score)))
