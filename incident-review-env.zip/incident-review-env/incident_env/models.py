from __future__ import annotations

from typing import Any, Dict, List, Literal, Optional

from pydantic import BaseModel, Field


ActionType = Literal[
    "classify_alert",
    "query_logs",
    "set_hypothesis",
    "issue_remediation",
    "write_postmortem",
]
TaskType = Literal["alert_triage", "root_cause", "full_resolution"]


class Action(BaseModel):
    action_type: ActionType
    payload: Dict[str, Any] = Field(default_factory=dict)


class Reward(BaseModel):
    total: float = Field(ge=0.0, le=1.0)
    triage: float = Field(ge=0.0, le=1.0)
    rca: float = Field(ge=0.0, le=1.0)
    postmortem: float = Field(ge=0.0, le=1.0)
    efficiency: float = Field(ge=0.0, le=1.0)
    penalty: float = Field(default=0.0)


class AlertRecord(BaseModel):
    id: str
    source: str
    service: str
    severity: str
    message: str
    timestamp: str


class Observation(BaseModel):
    task: TaskType
    step_count: int
    max_steps: int
    scenario_id: str
    scenario_title: str
    alerts: List[AlertRecord]
    visible_logs: List[str]
    metrics: Dict[str, float]
    active_hypothesis: Optional[str] = None
    remediation_history: List[str] = Field(default_factory=list)
    postmortem_submitted: bool = False
    partial_scores: Dict[str, float] = Field(default_factory=dict)
    hints: List[str] = Field(default_factory=list)
    degraded: bool = False


class ResetResponse(BaseModel):
    observation: Observation
    reward: Reward
    done: bool
    info: Dict[str, Any] = Field(default_factory=dict)


class StepResponse(BaseModel):
    observation: Observation
    reward: Reward
    done: bool
    info: Dict[str, Any] = Field(default_factory=dict)


class EnvState(BaseModel):
    task: TaskType
    step_count: int
    max_steps: int
    scenario_id: str
    scenario_title: str
    scenario_root_cause: str
    alerts: List[AlertRecord]
    visible_logs: List[str]
    all_logs: List[str]
    metrics: Dict[str, float]
    ground_truth_alert_labels: Dict[str, str]
    classifications: Dict[str, str]
    hypothesis: Optional[str]
    remediation_history: List[str]
    remediation_success: bool
    postmortem: Optional[Dict[str, Any]]
    reward: Reward
    degraded: bool
    done: bool
