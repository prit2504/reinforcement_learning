from incident_env.scenarios.bad_deploy import SCENARIO as BAD_DEPLOY
from incident_env.scenarios.db_overload import SCENARIO as DB_OVERLOAD
from incident_env.scenarios.high_latency import SCENARIO as HIGH_LATENCY
from incident_env.scenarios.memory_leak import SCENARIO as MEMORY_LEAK

ALL_SCENARIOS = [DB_OVERLOAD, MEMORY_LEAK, BAD_DEPLOY, HIGH_LATENCY]

__all__ = ["ALL_SCENARIOS", "DB_OVERLOAD", "MEMORY_LEAK", "BAD_DEPLOY", "HIGH_LATENCY"]
