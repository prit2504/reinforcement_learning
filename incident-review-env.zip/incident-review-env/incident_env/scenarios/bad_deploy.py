from __future__ import annotations

from incident_env.scenarios.base import Scenario


SCENARIO = Scenario(
    scenario_id="bad_deploy",
    title="Bad Deployment Breaks Authentication",
    service="auth-service",
    summary="A malformed configuration rollout points auth-service to an invalid certificate bundle, causing authentication failures.",
    alerts=[
        {"id": "C01", "source": "pagerduty", "service": "auth-service", "severity": "critical", "message": "Auth error rate above 18%", "timestamp": "2026-04-06T08:40:00Z"},
        {"id": "C02", "source": "prometheus", "service": "auth-service", "severity": "critical", "message": "TLS handshake failures above 500/min", "timestamp": "2026-04-06T08:40:12Z"},
        {"id": "C03", "source": "prometheus", "service": "web-gateway", "severity": "critical", "message": "Login endpoint 5xx above 14%", "timestamp": "2026-04-06T08:40:24Z"},
        {"id": "C04", "source": "prometheus", "service": "auth-service", "severity": "warning", "message": "Deployment completed 6m ago", "timestamp": "2026-04-06T08:40:36Z"},
        {"id": "C05", "source": "prometheus", "service": "auth-service", "severity": "warning", "message": "Config reload count increased", "timestamp": "2026-04-06T08:40:48Z"},
        {"id": "C06", "source": "prometheus", "service": "payments-api", "severity": "warning", "message": "Checkout auth dependency retries growing", "timestamp": "2026-04-06T08:41:00Z"},
        {"id": "C07", "source": "prometheus", "service": "auth-service", "severity": "warning", "message": "Certificate verify failures above threshold", "timestamp": "2026-04-06T08:41:12Z"},
        {"id": "C08", "source": "prometheus", "service": "identity-db", "severity": "info", "message": "DB latency nominal", "timestamp": "2026-04-06T08:41:24Z"},
        {"id": "C09", "source": "cloudwatch", "service": "cdn", "severity": "info", "message": "Edge latency stable", "timestamp": "2026-04-06T08:41:36Z"},
        {"id": "C10", "source": "prometheus", "service": "auth-service", "severity": "critical", "message": "Token issuance rate dropped 70%", "timestamp": "2026-04-06T08:41:48Z"},
        {"id": "C11", "source": "prometheus", "service": "auth-service", "severity": "warning", "message": "HTTP request volume steady", "timestamp": "2026-04-06T08:42:00Z"},
        {"id": "C12", "source": "pagerduty", "service": "customer-support", "severity": "warning", "message": "Multiple user login complaints", "timestamp": "2026-04-06T08:42:12Z"},
        {"id": "C13", "source": "prometheus", "service": "auth-service", "severity": "warning", "message": "Pod CPU normal", "timestamp": "2026-04-06T08:42:24Z"},
        {"id": "C14", "source": "prometheus", "service": "auth-service", "severity": "warning", "message": "Config checksum changed", "timestamp": "2026-04-06T08:42:36Z"},
        {"id": "C15", "source": "prometheus", "service": "search-api", "severity": "info", "message": "Search traffic healthy", "timestamp": "2026-04-06T08:42:48Z"},
        {"id": "C16", "source": "prometheus", "service": "auth-service", "severity": "critical", "message": "SLO burn rate critical for sign-in", "timestamp": "2026-04-06T08:43:00Z"},
        {"id": "C17", "source": "prometheus", "service": "web-gateway", "severity": "warning", "message": "Session creation failures increased", "timestamp": "2026-04-06T08:43:12Z"},
        {"id": "C18", "source": "prometheus", "service": "auth-service", "severity": "warning", "message": "Canary error rate above baseline", "timestamp": "2026-04-06T08:43:24Z"},
        {"id": "C19", "source": "prometheus", "service": "auth-service", "severity": "warning", "message": "Deploy pipeline marked success", "timestamp": "2026-04-06T08:43:36Z"},
        {"id": "C20", "source": "prometheus", "service": "auth-service", "severity": "warning", "message": "mTLS upstream failures with identity provider", "timestamp": "2026-04-06T08:43:48Z"},
    ],
    logs=[
        "2026-04-06T08:40:16Z auth-service app[55]: ERROR x509: certificate signed by unknown authority while connecting to idp.internal",
        "2026-04-06T08:40:31Z auth-service deploy[11]: applied config bundle auth-service-config-v184",
        "2026-04-06T08:40:59Z auth-service app[55]: WARN cert bundle path /etc/certs/idp-chain.pem not found, falling back to empty trust store",
        "2026-04-06T08:41:21Z web-gateway app[71]: upstream auth-service responded 502 for /login",
        "2026-04-06T08:41:47Z auth-service app[55]: INFO release=2026.04.06.4 config_sha=91ad22f",
        "2026-04-06T08:42:10Z auth-service app[55]: ERROR tls handshake failure: remote certificate validation failed",
    ],
    metrics={"cpu": 42.0, "latency": 1210.0, "memory": 58.0},
    root_cause="bad auth-service deploy shipped invalid certificate bundle configuration",
    aliases=[
        "invalid cert bundle in auth deploy",
        "misconfigured auth deployment broke tls to identity provider",
        "bad rollout changed certificate path for auth service",
    ],
    ground_truth_alert_labels={
        "C01": "symptom", "C02": "cause", "C03": "symptom", "C04": "cause", "C05": "cause", "C06": "symptom",
        "C07": "cause", "C08": "noise", "C09": "noise", "C10": "symptom", "C11": "noise", "C12": "symptom",
        "C13": "noise", "C14": "cause", "C15": "noise", "C16": "symptom", "C17": "symptom", "C18": "cause",
        "C19": "noise", "C20": "symptom",
    },
    remediation_commands=[
        "rollback auth-service deploy",
        "restore valid certificate bundle path",
        "restart auth-service pods",
    ],
    timeline_reference=[
        "08:40 UTC login failures started immediately after the auth-service deployment.",
        "08:41 UTC logs showed certificate validation failures and a missing trust bundle path.",
        "08:42 UTC the deployment was rolled back and the valid certificate bundle restored.",
        "08:44 UTC sign-in traffic recovered and error rate returned to baseline.",
    ],
    impact="Users were unable to log in because the authentication service could not complete TLS handshakes with the identity provider after a bad configuration deploy.",
    action_items=[
        "Add certificate bundle existence validation to deployment health checks.",
        "Require canary login synthetic verification before global rollout.",
        "Version and test trust store configuration separately from app code.",
    ],
    log_hints=["certificate", "tls", "deploy", "config"],
)
