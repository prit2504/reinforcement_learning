from __future__ import annotations

from dataclasses import dataclass, field
from typing import Dict, List


@dataclass(frozen=True)
class Scenario:
    scenario_id: str
    title: str
    service: str
    summary: str
    alerts: List[dict]
    logs: List[str]
    metrics: Dict[str, float]
    root_cause: str
    aliases: List[str]
    ground_truth_alert_labels: Dict[str, str]
    remediation_commands: List[str]
    timeline_reference: List[str]
    impact: str
    action_items: List[str]
    log_hints: List[str] = field(default_factory=list)
