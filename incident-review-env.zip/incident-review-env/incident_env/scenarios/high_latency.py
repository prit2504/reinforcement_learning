from __future__ import annotations

from incident_env.scenarios.base import Scenario


SCENARIO = Scenario(
    scenario_id="high_latency",
    title="Latency Spike from Dependency Retry Storm",
    service="payments-api",
    summary="A downstream fraud-check service is timing out, triggering aggressive retries and cascading latency in the payments path.",
    alerts=[
        {"id": "D01", "source": "pagerduty", "service": "payments-api", "severity": "critical", "message": "Payments p95 latency above 2.4s", "timestamp": "2026-04-06T11:10:00Z"},
        {"id": "D02", "source": "prometheus", "service": "payments-api", "severity": "critical", "message": "Pending request queue above 1500", "timestamp": "2026-04-06T11:10:12Z"},
        {"id": "D03", "source": "prometheus", "service": "fraud-check", "severity": "critical", "message": "Fraud-check timeout rate above 25%", "timestamp": "2026-04-06T11:10:24Z"},
        {"id": "D04", "source": "prometheus", "service": "payments-api", "severity": "warning", "message": "Retry attempts per request above 4", "timestamp": "2026-04-06T11:10:36Z"},
        {"id": "D05", "source": "prometheus", "service": "payments-api", "severity": "warning", "message": "Worker thread saturation at 93%", "timestamp": "2026-04-06T11:10:48Z"},
        {"id": "D06", "source": "prometheus", "service": "fraud-check", "severity": "warning", "message": "Dependency latency above 1.8s", "timestamp": "2026-04-06T11:11:00Z"},
        {"id": "D07", "source": "prometheus", "service": "payments-api", "severity": "critical", "message": "Card authorization failure rate increased", "timestamp": "2026-04-06T11:11:12Z"},
        {"id": "D08", "source": "prometheus", "service": "feature-flag", "severity": "info", "message": "Kill switch disabled", "timestamp": "2026-04-06T11:11:24Z"},
        {"id": "D09", "source": "prometheus", "service": "payments-api", "severity": "warning", "message": "Circuit breaker remains closed", "timestamp": "2026-04-06T11:11:36Z"},
        {"id": "D10", "source": "prometheus", "service": "payments-api", "severity": "warning", "message": "CPU usage elevated to 82%", "timestamp": "2026-04-06T11:11:48Z"},
        {"id": "D11", "source": "prometheus", "service": "payments-db", "severity": "info", "message": "Transaction DB healthy", "timestamp": "2026-04-06T11:12:00Z"},
        {"id": "D12", "source": "prometheus", "service": "fraud-check", "severity": "warning", "message": "Region eu-west backend unhealthy", "timestamp": "2026-04-06T11:12:12Z"},
        {"id": "D13", "source": "prometheus", "service": "payments-api", "severity": "warning", "message": "Timeout fallback disabled for fraud-check", "timestamp": "2026-04-06T11:12:24Z"},
        {"id": "D14", "source": "pagerduty", "service": "customer-support", "severity": "warning", "message": "Customers report spinning payments page", "timestamp": "2026-04-06T11:12:36Z"},
        {"id": "D15", "source": "prometheus", "service": "payments-api", "severity": "critical", "message": "SLO burn rate critical for charge API", "timestamp": "2026-04-06T11:12:48Z"},
        {"id": "D16", "source": "prometheus", "service": "network", "severity": "info", "message": "Core network packet loss normal", "timestamp": "2026-04-06T11:13:00Z"},
        {"id": "D17", "source": "prometheus", "service": "payments-api", "severity": "warning", "message": "Queued retry jobs above 900", "timestamp": "2026-04-06T11:13:12Z"},
        {"id": "D18", "source": "prometheus", "service": "fraud-check", "severity": "warning", "message": "Timeouts isolated to one region", "timestamp": "2026-04-06T11:13:24Z"},
        {"id": "D19", "source": "prometheus", "service": "cache", "severity": "info", "message": "Payment session cache healthy", "timestamp": "2026-04-06T11:13:36Z"},
        {"id": "D20", "source": "prometheus", "service": "payments-api", "severity": "warning", "message": "Error budget consumption accelerated after retry storm", "timestamp": "2026-04-06T11:13:48Z"},
    ],
    logs=[
        "2026-04-06T11:10:14Z payments-api app[87]: WARN fraud-check timed out after 1200ms, retrying attempt=2",
        "2026-04-06T11:10:39Z payments-api app[87]: WARN retry budget exceeded but circuit breaker threshold not met",
        "2026-04-06T11:11:01Z fraud-check app[34]: ERROR upstream eu-west-1 model endpoint timed out",
        "2026-04-06T11:11:22Z payments-api app[87]: INFO feature flag payments.fraud_soft_fail=false",
        "2026-04-06T11:11:55Z payments-api app[87]: WARN request thread blocked waiting on fraud-check future",
        "2026-04-06T11:12:19Z fraud-check router[12]: WARN region=eu-west-1 unhealthy target pool size=0",
        "2026-04-06T11:12:43Z payments-api app[87]: ERROR charge flow exceeded end-to-end timeout because retries stacked",
    ],
    metrics={"cpu": 82.0, "latency": 2470.0, "memory": 66.0},
    root_cause="fraud-check regional outage triggered retry storm in payments api",
    aliases=[
        "payments retry storm from fraud check outage",
        "downstream fraud service timeouts caused cascading latency",
        "regional fraud-check outage with aggressive retries",
    ],
    ground_truth_alert_labels={
        "D01": "symptom", "D02": "symptom", "D03": "cause", "D04": "cause", "D05": "symptom", "D06": "cause",
        "D07": "symptom", "D08": "noise", "D09": "cause", "D10": "symptom", "D11": "noise", "D12": "cause",
        "D13": "cause", "D14": "symptom", "D15": "symptom", "D16": "noise", "D17": "symptom", "D18": "cause",
        "D19": "noise", "D20": "symptom",
    },
    remediation_commands=[
        "enable fraud soft fail",
        "open circuit breaker for fraud-check",
        "route fraud-check away from eu-west-1",
    ],
    timeline_reference=[
        "11:10 UTC payment latency alerts fired while the fraud-check dependency began timing out.",
        "11:11 UTC logs showed retries stacking because the circuit breaker stayed closed.",
        "11:12 UTC the team enabled soft-fail behavior and redirected fraud traffic away from the unhealthy region.",
        "11:14 UTC queue depth and payment latency returned toward baseline.",
    ],
    impact="Customers experienced slow or failed payment attempts because the payments API kept retrying calls to an unhealthy fraud-check dependency instead of failing open or isolating the region.",
    action_items=[
        "Cap retries and include retry-budget enforcement in the charge path.",
        "Add automatic regional failover for fraud-check.",
        "Test soft-fail circuit breaker behavior during dependency brownouts.",
    ],
    log_hints=["retry", "fraud", "timeout", "circuit"],
)
