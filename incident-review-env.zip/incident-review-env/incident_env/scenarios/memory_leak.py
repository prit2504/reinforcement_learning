from __future__ import annotations

from incident_env.scenarios.base import Scenario


SCENARIO = Scenario(
    scenario_id="memory_leak",
    title="Gradual Memory Leak in Recommender Service",
    service="recommendation-api",
    summary="A cache object leak in the recommendation service causes pods to OOM and restart under normal traffic.",
    alerts=[
        {"id": "B01", "source": "prometheus", "service": "recommendation-api", "severity": "critical", "message": "Container restarts above 5 in 10m", "timestamp": "2026-04-06T09:20:00Z"},
        {"id": "B02", "source": "prometheus", "service": "recommendation-api", "severity": "critical", "message": "Memory usage above 94%", "timestamp": "2026-04-06T09:20:15Z"},
        {"id": "B03", "source": "prometheus", "service": "recommendation-api", "severity": "warning", "message": "Heap growth slope elevated for 45m", "timestamp": "2026-04-06T09:20:30Z"},
        {"id": "B04", "source": "prometheus", "service": "recommendation-api", "severity": "warning", "message": "GC pause time above 350ms", "timestamp": "2026-04-06T09:20:45Z"},
        {"id": "B05", "source": "pagerduty", "service": "homepage", "severity": "critical", "message": "Homepage personalization degraded", "timestamp": "2026-04-06T09:21:00Z"},
        {"id": "B06", "source": "prometheus", "service": "recommendation-api", "severity": "warning", "message": "Pod eviction risk elevated", "timestamp": "2026-04-06T09:21:15Z"},
        {"id": "B07", "source": "prometheus", "service": "redis", "severity": "info", "message": "Redis CPU normal", "timestamp": "2026-04-06T09:21:30Z"},
        {"id": "B08", "source": "prometheus", "service": "recommendation-api", "severity": "warning", "message": "P95 latency above 900ms", "timestamp": "2026-04-06T09:21:45Z"},
        {"id": "B09", "source": "prometheus", "service": "ad-service", "severity": "info", "message": "Campaign updates healthy", "timestamp": "2026-04-06T09:22:00Z"},
        {"id": "B10", "source": "prometheus", "service": "recommendation-api", "severity": "critical", "message": "OOMKilled events detected", "timestamp": "2026-04-06T09:22:15Z"},
        {"id": "B11", "source": "prometheus", "service": "recommendation-api", "severity": "warning", "message": "Cache hit ratio unexpectedly rising", "timestamp": "2026-04-06T09:22:30Z"},
        {"id": "B12", "source": "prometheus", "service": "recommendation-api", "severity": "warning", "message": "Pod count autoscaled to max", "timestamp": "2026-04-06T09:22:45Z"},
        {"id": "B13", "source": "prometheus", "service": "recommendation-api", "severity": "warning", "message": "Request concurrency stable", "timestamp": "2026-04-06T09:23:00Z"},
        {"id": "B14", "source": "prometheus", "service": "catalog-api", "severity": "info", "message": "Catalog p95 latency nominal", "timestamp": "2026-04-06T09:23:15Z"},
        {"id": "B15", "source": "prometheus", "service": "recommendation-api", "severity": "critical", "message": "Error rate above 8%", "timestamp": "2026-04-06T09:23:30Z"},
        {"id": "B16", "source": "prometheus", "service": "k8s", "severity": "warning", "message": "Node memory pressure warning", "timestamp": "2026-04-06T09:23:45Z"},
        {"id": "B17", "source": "prometheus", "service": "recommendation-api", "severity": "warning", "message": "Old generation usage above 88%", "timestamp": "2026-04-06T09:24:00Z"},
        {"id": "B18", "source": "cloudwatch", "service": "ingestion-worker", "severity": "info", "message": "Batch pipeline on schedule", "timestamp": "2026-04-06T09:24:15Z"},
        {"id": "B19", "source": "prometheus", "service": "recommendation-api", "severity": "warning", "message": "Heap not returning after full GC", "timestamp": "2026-04-06T09:24:30Z"},
        {"id": "B20", "source": "prometheus", "service": "recommendation-api", "severity": "warning", "message": "New cache entry cardinality climbing", "timestamp": "2026-04-06T09:24:45Z"},
    ],
    logs=[
        "2026-04-06T09:20:13Z recommendation-api app[22]: WARN cache size=518204 entries and growing",
        "2026-04-06T09:20:28Z recommendation-api app[22]: INFO deploy version=2026.04.06-rc2 enabled personalized fallback cache",
        "2026-04-06T09:20:46Z recommendation-api app[22]: WARN heap dump suggests RecommendationContext retained by CacheWarmService",
        "2026-04-06T09:21:09Z kubelet node-3: Killing container because it exceeded memory limit",
        "2026-04-06T09:21:37Z recommendation-api app[22]: WARN cache eviction callback not firing for recommendation_context",
        "2026-04-06T09:22:02Z recommendation-api app[22]: INFO traffic level unchanged from prior hour",
        "2026-04-06T09:22:41Z recommendation-api jvm[22]: Full GC completed but retained heap remains at 91%",
    ],
    metrics={"cpu": 64.0, "latency": 930.0, "memory": 95.0},
    root_cause="memory leak in recommendation cache warm service after recent deploy",
    aliases=[
        "recommendation cache leak causing oom kills",
        "cache warm service retained objects and exhausted memory",
        "recent deploy introduced memory leak in recommendation api",
    ],
    ground_truth_alert_labels={
        "B01": "symptom", "B02": "symptom", "B03": "cause", "B04": "symptom", "B05": "symptom", "B06": "symptom",
        "B07": "noise", "B08": "symptom", "B09": "noise", "B10": "symptom", "B11": "cause", "B12": "symptom",
        "B13": "noise", "B14": "noise", "B15": "symptom", "B16": "symptom", "B17": "symptom", "B18": "noise",
        "B19": "cause", "B20": "cause",
    },
    remediation_commands=[
        "rollback recommendation-api deploy",
        "disable personalized fallback cache",
        "restart leaking pods after rollback",
    ],
    timeline_reference=[
        "09:20 UTC recommendation pods began restarting because memory usage crossed limits.",
        "09:21 UTC heap-related logs pointed to retained cache warm service objects after the latest deploy.",
        "09:23 UTC the team disabled the fallback cache and rolled back the release.",
        "09:26 UTC memory stabilized and homepage personalization recovered.",
    ],
    impact="Homepage visitors saw degraded or missing personalized recommendations while the recommendation service repeatedly hit OOM conditions and restarted, increasing latency and error rates.",
    action_items=[
        "Add memory regression tests for recommendation cache changes.",
        "Ship canary heap telemetry diffing for recommendation-api deployments.",
        "Cap cache cardinality and validate eviction hooks in CI.",
    ],
    log_hints=["cache", "heap", "oom", "deploy"],
)
