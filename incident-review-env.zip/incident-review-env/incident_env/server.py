from __future__ import annotations

from typing import Optional

from fastapi import FastAPI
from pydantic import BaseModel

from incident_env.env import IncidentReviewEnv
from incident_env.models import Action, StepResponse, TaskType


class ResetRequest(BaseModel):
    task: Optional[TaskType] = None
    seed: Optional[int] = None


app = FastAPI(title="incident-review-env", version="1.0.0")
ENV = IncidentReviewEnv()


@app.get("/health")
def health() -> dict[str, str]:
    return {"status": "ok"}


@app.post("/reset")
def reset(request: ResetRequest) -> StepResponse:
    global ENV
    if request.seed is not None:
        ENV = IncidentReviewEnv(seed=request.seed)
    observation = ENV.reset(task=request.task)
    reward = ENV.last_reward
    return StepResponse(observation=observation, reward=reward, done=False, info={"task": observation.task})


@app.post("/step")
def step(action: Action) -> StepResponse:
    observation, reward, done, info = ENV.step(action)
    return StepResponse(observation=observation, reward=reward, done=done, info=info)


@app.get("/state")
def state() -> dict:
    return ENV.state().model_dump()
