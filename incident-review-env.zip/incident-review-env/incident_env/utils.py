from __future__ import annotations

import re
from typing import Iterable, Sequence


UNSAFE_PATTERNS = (
    "drop table",
    "delete all",
    "rm -rf /",
    "shutdown -h now",
    "truncate",
    "format disk",
)


def clamp(value: float, lower: float = 0.0, upper: float = 1.0) -> float:
    return max(lower, min(upper, value))


def canonicalize(text: str) -> str:
    normalized = re.sub(r"[^a-z0-9\\s]+", " ", text.lower()).strip()
    return re.sub(r"\\s+", " ", normalized)


def token_set(text: str) -> set[str]:
    return {token for token in canonicalize(text).split(" ") if token}


def overlap_ratio(a: str, b: str) -> float:
    left = token_set(a)
    right = token_set(b)
    if not left or not right:
        return 0.0
    return len(left & right) / len(left | right)


def contains_any(text: str, patterns: Sequence[str]) -> bool:
    haystack = canonicalize(text)
    return any(canonicalize(pattern) in haystack for pattern in patterns)


def is_unsafe_command(command: str) -> bool:
    return contains_any(command, UNSAFE_PATTERNS)


def unique_preserve_order(values: Iterable[str]) -> list[str]:
    seen: set[str] = set()
    result: list[str] = []
    for value in values:
        if value not in seen:
            seen.add(value)
            result.append(value)
    return result
