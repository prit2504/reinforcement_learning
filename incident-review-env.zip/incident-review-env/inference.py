from __future__ import annotations

import json
import os
from typing import Any, Dict

import requests


DEFAULT_ENV_URL = os.getenv("ENV_BASE_URL", "http://127.0.0.1:7860")
API_BASE_URL = os.getenv("API_BASE_URL", "http://nav0357:19434")
MODEL_NAME = os.getenv("MODEL_NAME", "llama3.1:8b")
MAX_STEPS = 8


def build_client() -> str:
    return API_BASE_URL.rstrip("/")


def call_model(client: str, observation: Dict[str, Any]) -> Dict[str, Any]:
    prompt = (
        "You are solving a deterministic incident-response RL task. "
        "Return exactly one JSON object with keys action_type and payload. "
        "Allowed action_type values: classify_alert, query_logs, set_hypothesis, issue_remediation, write_postmortem. "
        "Prioritize safe remediation. Observation JSON follows:\n"
        f"{json.dumps(observation, ensure_ascii=True)}"
    )

    response = requests.post(
        f"{client}/api/chat",
        json={
            "model": MODEL_NAME,
            "format": "json",
            "stream": False,
            "options": {"temperature": 0},
            "messages": [
                {"role": "system", "content": "Return strict JSON only."},
                {"role": "user", "content": prompt},
            ],
        },
        timeout=120,
    )
    response.raise_for_status()
    payload = response.json()
    message = payload.get("message", {})
    content = message.get("content", "{}")
    parsed = json.loads(content)
    if "action_type" not in parsed or "payload" not in parsed:
        raise ValueError("Model response missing action_type or payload.")
    return parsed


def heuristic_action(observation: Dict[str, Any]) -> Dict[str, Any]:
    scenario_id = observation["scenario_id"]
    visible_logs = " ".join(observation.get("visible_logs", [])).lower()
    alerts = observation.get("alerts", [])
    step_count = observation.get("step_count", 0)

    scenario_rca = {
        "db_overload": "unbounded analytics backfill saturating the primary postgres database",
        "memory_leak": "memory leak in recommendation cache warm service after recent deploy",
        "bad_deploy": "bad auth-service deploy shipped invalid certificate bundle configuration",
        "high_latency": "fraud-check regional outage triggered retry storm in payments api",
    }
    remediations = {
        "db_overload": "pause analytics backfill",
        "memory_leak": "rollback recommendation-api deploy",
        "bad_deploy": "rollback auth-service deploy",
        "high_latency": "enable fraud soft fail",
    }

    if step_count == 0 and alerts:
        alert = alerts[0]
        label = "cause" if any(word in alert["message"].lower() for word in ["deploy", "timeout", "cpu", "memory", "query"]) else "symptom"
        return {"action_type": "classify_alert", "payload": {"id": alert["id"], "label": label}}
    if step_count == 1:
        keyword_map = {
            "db_overload": "backfill",
            "memory_leak": "cache",
            "bad_deploy": "certificate",
            "high_latency": "retry",
        }
        return {"action_type": "query_logs", "payload": {"keyword": keyword_map.get(scenario_id, "error")}}
    if step_count == 2 or ("deploy" in visible_logs or "retry" in visible_logs or "cache" in visible_logs):
        return {"action_type": "set_hypothesis", "payload": {"cause": scenario_rca.get(scenario_id, "service incident")}}
    if observation["task"] == "full_resolution" and step_count <= 4 and not observation.get("remediation_history"):
        return {"action_type": "issue_remediation", "payload": {"command": remediations.get(scenario_id, "restart service")}}
    if observation["task"] == "full_resolution":
        return {
            "action_type": "write_postmortem",
            "payload": {
                "timeline": [
                    "Alert fired and on-call acknowledged the incident.",
                    "Logs and metrics narrowed the investigation to the likely dependency or rollout issue.",
                    "A safe remediation was applied and service health recovered.",
                ],
                "impact": "Customers experienced elevated failures and latency during the incident window, which affected a user-facing production path until the team contained and mitigated the issue safely.",
                "rca": scenario_rca.get(scenario_id, "service incident"),
                "action_items": [
                    "Add stronger pre-deployment safety checks.",
                    "Improve automated detection and rollback guardrails.",
                ],
            },
        }
    if alerts:
        alert = alerts[min(step_count, len(alerts) - 1)]
        label = "noise" if alert["severity"] == "info" else "symptom"
        return {"action_type": "classify_alert", "payload": {"id": alert["id"], "label": label}}
    return {"action_type": "query_logs", "payload": {"keyword": "error"}}


def select_action(client: str, observation: Dict[str, Any]) -> Dict[str, Any]:
    try:
        return call_model(client, observation)
    except Exception:
        return heuristic_action(observation)


def main() -> None:
    client = build_client()
    reset_payload = {"task": "full_resolution"}
    reset_response = requests.post(f"{DEFAULT_ENV_URL}/reset", json=reset_payload, timeout=30)
    reset_response.raise_for_status()
    state = reset_response.json()
    observation = state["observation"]
    task = observation["task"]

    rewards: list[float] = [float(state["reward"]["total"])]
    success = False
    done = False
    steps_taken = 0

    print(f"[START] task={task} env=incident-review-env model={MODEL_NAME}")

    for step_index in range(1, MAX_STEPS + 1):
        error_value = "None"
        try:
            action = select_action(client, observation)
            step_response = requests.post(f"{DEFAULT_ENV_URL}/step", json=action, timeout=30)
            step_response.raise_for_status()
            payload = step_response.json()
            reward_value = float(payload["reward"]["total"])
            done = bool(payload["done"])
            rewards.append(reward_value)
            steps_taken = step_index
            observation = payload["observation"]
            success = reward_value >= 0.75 or done
            print(
                f"[STEP] step={step_index} action={json.dumps(action, ensure_ascii=True)} "
                f"reward={reward_value:.4f} done={done} error={error_value}"
            )
            if done:
                break
        except Exception as exc:
            error_value = str(exc).replace("\n", " ")
            print(
                f"[STEP] step={step_index} action={json.dumps({'action_type': 'error', 'payload': {}}, ensure_ascii=True)} "
                f"reward=0.0000 done=False error={error_value}"
            )
            steps_taken = step_index
            break

    score = rewards[-1] if rewards else 0.0
    print(f"[END] success={success} steps={steps_taken} score={score:.4f} rewards={json.dumps(rewards)}")


if __name__ == "__main__":
    main()
