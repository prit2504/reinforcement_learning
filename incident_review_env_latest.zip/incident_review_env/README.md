# incident-review-env

`incident-review-env` is an OpenEnv-style incident-response environment for evaluating agents on structured production incidents. Instead of chatting freely, the agent must work through a bounded workflow: read alerts and logs, form a root-cause hypothesis, choose a safe remediation, and submit a postmortem.

## Environment Description and Motivation

This environment is designed to test whether an LLM agent can handle realistic on-call style reasoning with deterministic grading.

Why this project exists:
- incident response is a high-value operational task
- free-form evaluation is noisy and hard to compare
- structured environments make agent behavior measurable and reproducible

The environment ships with four incident scenarios:
- `db_overload`
- `memory_leak`
- `bad_deploy`
- `high_latency`

Each scenario includes alerts, logs, metrics, a ground-truth root cause, accepted remediations, and postmortem expectations.

## Architecture

```text
inference.py / client.py
        |
        v
FastAPI app: incident_review_env.server.app
        |
        v
Environment: incident_review_env.server.environment
        |
        +-- scenarios/
        +-- graders/
        +-- models.py
```

Main components:
- `server/app.py`: FastAPI entry point with `/health`, `/reset`, `/step`, `/state`
- `server/environment.py`: core environment state machine and reward logic
- `scenarios/`: deterministic incident datasets
- `graders/`: triage, RCA, and postmortem scoring
- `inference.py`: baseline agent loop

## Observation Space

Each step returns a structured observation with the current incident state.

Observation fields:
- `task`
- `step_count`
- `max_steps`
- `scenario_id`
- `scenario_title`
- `alerts`
- `visible_logs`
- `metrics`
- `active_hypothesis`
- `remediation_history`
- `postmortem_submitted`
- `partial_scores`
- `hints`
- `degraded`

In practice, the agent uses this information to decide:
- which alerts are symptoms, causes, or noise
- which log keywords to query
- what the likely RCA is
- which remediation to issue
- what to include in the postmortem

## Action Space

The environment accepts five action types.

`classify_alert`
- payload: `{"id": "<alert id>", "label": "symptom|cause|noise"}`
- use: assign a label to one alert

`query_logs`
- payload: `{"keyword": "<term>"}`
- use: reveal more logs related to the keyword

`set_hypothesis`
- payload: `{"cause": "<root cause text>"}`
- use: submit the current RCA hypothesis

`issue_remediation`
- payload: `{"command": "<safe command>"}`
- use: apply a mitigation or rollback

`write_postmortem`
- payload:
```json
{
  "timeline": ["...", "...", "..."],
  "impact": "...",
  "rca": "...",
  "action_items": ["...", "..."]
}
```
- use: submit the final incident summary

## Tasks and Expected Difficulty

The environment supports three tasks.

`alert_triage`
- objective: classify alerts correctly
- expected difficulty: easy

`root_cause`
- objective: triage enough evidence and identify the correct RCA
- expected difficulty: medium

`full_resolution`
- objective: triage, diagnose, remediate, and submit a valid postmortem
- expected difficulty: hard

The baseline agent uses `full_resolution`.

## Reward Logic

Reward is deterministic and normalized to `[0.0, 1.0]`.

Formula:

```text
total =
  0.30 * triage_score +
  0.30 * rca_score +
  0.30 * postmortem_score +
  0.10 * efficiency_score
```

Reward components:
- `triage_score`: how well alerts were classified
- `rca_score`: how closely the submitted hypothesis matches the true cause
- `postmortem_score`: quality of timeline, impact, RCA, and action items
- `efficiency_score`: bonus for solving in fewer steps

The environment can also apply penalties for unsafe or low-quality behavior before clamping the final score.

## Setup and Usage

From the repository root:

```powershell
python -m venv .venv
.venv\Scripts\Activate.ps1
pip install -r requirements.txt
```

Start the API server:

```powershell
uvicorn incident_review_env.server.app:app --host 0.0.0.0 --port 7860
```

Run the baseline:

```powershell
python -m incident_review_env.inference
```

Run tests:

```powershell
python -m unittest incident_review_env.test_smoke -v
```

Useful environment variables:
- `ENV_BASE_URL`
- `API_BASE_URL`
- `MODEL_NAME`
- `HF_TOKEN`
- `RUN_SEED`
- `MAX_STEPS`
- `SUCCESS_THRESHOLD`

## Baseline Scores

Current deterministic baseline behavior with `RUN_SEED=42`:
- task: `full_resolution`
- typical step count: `9`
- typical final score: about `0.74` to `0.75`
- success threshold: configurable, commonly `0.60`

Example deterministic run:

```text
[START] task=full_resolution env=incident-review-env model=llama3.1:8b backend=http://nav0357:19434 seed=42
[STEP] step=1 action={"action_type": "classify_alert", "payload": {"id": "A21", "label": "symptom"}} reward=0.1067 done=False error=None
[STEP] step=2 action={"action_type": "classify_alert", "payload": {"id": "A04", "label": "cause"}} reward=0.1300 done=False error=None
[STEP] step=3 action={"action_type": "classify_alert", "payload": {"id": "A11", "label": "noise"}} reward=0.1486 done=False error=None
[STEP] step=4 action={"action_type": "classify_alert", "payload": {"id": "A07", "label": "cause"}} reward=0.1624 done=False error=None
[STEP] step=5 action={"action_type": "classify_alert", "payload": {"id": "A01", "label": "symptom"}} reward=0.1665 done=False error=None
[STEP] step=6 action={"action_type": "classify_alert", "payload": {"id": "A12", "label": "noise"}} reward=0.1779 done=False error=None
[STEP] step=7 action={"action_type": "set_hypothesis", "payload": {"cause": "unbounded analytics backfill saturating the primary postgres database"}} reward=0.4679 done=False error=None
[STEP] step=8 action={"action_type": "issue_remediation", "payload": {"command": "pause analytics backfill"}} reward=0.4579 done=False error=None
[STEP] step=9 action={"action_type": "write_postmortem", "payload": {"timeline": ["Automated alerts fired and the incident was acknowledged by the on-call responder.", "Logs, metrics, and alert signals were reviewed to narrow the issue to the most likely root cause.", "Mitigation was applied: pause analytics backfill."], "impact": "Customers experienced elevated failures or latency in analytics-worker, auth-service, checkout until the incident was mitigated. The responder used the available evidence to reduce risk and restore service health.", "rca": "unbounded analytics backfill saturating the primary postgres database", "action_items": ["Add stronger pre-deployment safety checks for production-impacting changes.", "Improve alert-to-remediation guardrails so similar incidents recover faster."]}} reward=0.7479 done=True error=None
[END] success=True steps=9 score=0.7479 rewards=[0.1, 0.10666666666666667, 0.13, 0.14857142857142858, 0.16238095238095235, 0.16648351648351645, 0.1779120879120879, 0.46791208791208794, 0.45791208791208793, 0.747912087912088]
```

## Notes

- The environment is deterministic under a fixed seed.
- Different seeds can be used to benchmark across scenarios.
- The baseline is reliable, but not optimal; there is still room to improve triage coverage and efficiency.
