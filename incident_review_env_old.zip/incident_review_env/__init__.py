from incident_review_env.inference import main

__all__ = ["main"]
