from __future__ import annotations

import os
from typing import Any, Dict

import requests


DEFAULT_ENV_URL = os.getenv("ENV_BASE_URL", "http://127.0.0.1:7860")


def build_env_url() -> str:
    return DEFAULT_ENV_URL.rstrip("/")


def reset_environment(base_url: str, payload: Dict[str, Any], timeout: float = 30) -> Dict[str, Any]:
    response = requests.post(f"{base_url}/reset", json=payload, timeout=timeout)
    response.raise_for_status()
    return response.json()


def step_environment(base_url: str, action: Dict[str, Any], timeout: float = 30) -> Dict[str, Any]:
    response = requests.post(f"{base_url}/step", json=action, timeout=timeout)
    response.raise_for_status()
    return response.json()


def get_environment_state(base_url: str, timeout: float = 30) -> Dict[str, Any]:
    response = requests.get(f"{base_url}/state", timeout=timeout)
    response.raise_for_status()
    return response.json()
