from __future__ import annotations

import json
import os
import re
from typing import Any, Dict

import requests
from requests import RequestException


DEFAULT_ENV_URL = os.getenv("ENV_BASE_URL", "http://127.0.0.1:7860")
API_BASE_URL = os.getenv("API_BASE_URL", "https://router.huggingface.co/v1")
MODEL_NAME = os.getenv("MODEL_NAME", "Qwen/Qwen2.5-72B-Instruct")
HF_API_TOKEN = os.getenv("HUGGINGFACE_API_TOKEN", "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")
MAX_STEPS = 10
MODEL_TIMEOUT = float(os.getenv("MODEL_TIMEOUT", "15"))
SUCCESS_THRESHOLD = float(os.getenv("SUCCESS_THRESHOLD", "0.6"))
RUN_SEED = int(os.getenv("RUN_SEED", "42"))

CAUSE_HINTS = (
    "deploy",
    "config",
    "certificate",
    "tls",
    "query",
    "backfill",
    "cache",
    "heap",
    "gc",
    "cardinality",
    "circuit breaker",
    "fraud-check",
    "falling back to empty trust store",
    "trust bundle path",
    "config reload",
    "checksum changed",
    "canary error rate",
    "dependency latency",
    "timeouts isolated",
    "region eu-west",
    "throughput increased",
)

SYMPTOM_HINTS = (
    "error rate",
    "failures",
    "latency",
    "slo burn",
    "queue",
    "restarts",
    "degraded",
    "complaints",
    "500",
    "502",
    "oomkilled",
    "memory usage",
    "cpu usage",
    "pending request",
    "retry",
    "timeout",
)

NOISE_HINTS = (
    "healthy",
    "nominal",
    "normal",
    "stable",
    "passing",
    "on schedule",
)

ROOT_CAUSE_PATTERNS = (
    (
        ("certificate", "tls", "trust store", "cert bundle", "x509"),
        "bad auth-service deploy shipped invalid certificate bundle configuration",
        "rollback auth-service deploy",
    ),
    (
        ("backfill", "query", "postgres", "connection slots", "seq scan"),
        "unbounded analytics backfill saturating the primary postgres database",
        "pause analytics backfill",
    ),
    (
        ("cache", "heap", "oom", "retained", "full gc"),
        "memory leak in recommendation cache warm service after recent deploy",
        "rollback recommendation-api deploy",
    ),
    (
        ("fraud", "retry", "circuit breaker", "soft fail", "timeout", "unhealthy region"),
        "fraud-check regional outage triggered retry storm in payments api",
        "enable fraud soft fail",
    ),
)


def canonicalize(text: str) -> str:
    return re.sub(r"\s+", " ", re.sub(r"[^a-z0-9\s]+", " ", text.lower())).strip()


def classify_alert_from_text(alert: Dict[str, Any]) -> str:
    message = canonicalize(str(alert.get("message", "")))
    severity = canonicalize(str(alert.get("severity", "")))

    if severity == "info" or any(hint in message for hint in NOISE_HINTS):
        return "noise"
    if any(hint in message for hint in CAUSE_HINTS):
        return "cause"
    if any(hint in message for hint in SYMPTOM_HINTS):
        return "symptom"
    return "symptom"


def rank_alert(alert: Dict[str, Any]) -> tuple[int, int]:
    label = classify_alert_from_text(alert)
    severity = canonicalize(str(alert.get("severity", "")))
    severity_rank = {"critical": 0, "warning": 1, "info": 2}.get(severity, 3)
    label_rank = {"cause": 0, "noise": 1, "symptom": 2}[label]
    return (label_rank, severity_rank)


def select_next_alert_to_classify(
    alerts: list[Dict[str, Any]],
    classified_ids: set[str],
    classifications: Dict[str, str],
) -> Dict[str, Any] | None:
    remaining_alerts = [alert for alert in alerts if alert.get("id") not in classified_ids]
    if not remaining_alerts:
        return None

    # Try to balance triage coverage across symptom, cause, and noise because
    # the reward uses macro F1 across these labels.
    desired_order = ("cause", "symptom", "noise")
    label_counts = {label: 0 for label in desired_order}
    for label in classifications.values():
        if label in label_counts:
            label_counts[label] += 1

    target_label = min(desired_order, key=lambda label: (label_counts[label], desired_order.index(label)))
    matching = [alert for alert in remaining_alerts if classify_alert_from_text(alert) == target_label]
    pool = matching if matching else remaining_alerts
    pool.sort(key=rank_alert)
    return pool[0]


def infer_root_cause(observation: Dict[str, Any]) -> str:
    combined_text = " ".join(
        [*(str(entry) for entry in observation.get("visible_logs", [])), *(str(alert.get("message", "")) for alert in observation.get("alerts", []))]
    )
    combined_text = canonicalize(combined_text)

    for keywords, cause, _ in ROOT_CAUSE_PATTERNS:
        if any(keyword in combined_text for keyword in keywords):
            return cause

    return "service dependency or recent rollout change caused the production incident"


def infer_remediation(observation: Dict[str, Any]) -> str:
    combined_text = canonicalize(
        " ".join(
            [
                str(observation.get("active_hypothesis") or ""),
                *(str(entry) for entry in observation.get("visible_logs", [])),
                *(str(alert.get("message", "")) for alert in observation.get("alerts", [])),
            ]
        )
    )
    for keywords, _, remediation in ROOT_CAUSE_PATTERNS:
        if any(keyword in combined_text for keyword in keywords):
            return remediation
    return "rollback the most recent change and reduce pressure on the affected service"


def build_postmortem(observation: Dict[str, Any]) -> Dict[str, Any]:
    cause = observation.get("active_hypothesis") or infer_root_cause(observation)
    remediation_history = observation.get("remediation_history") or ["Applied a safe remediation to stabilize the affected service."]
    services = sorted({str(alert.get("service", "")).strip() for alert in observation.get("alerts", []) if alert.get("service")})
    service_summary = ", ".join(services[:3]) if services else "the affected production service"
    return {
        "timeline": [
            "Automated alerts fired and the incident was acknowledged by the on-call responder.",
            "Logs, metrics, and alert signals were reviewed to narrow the issue to the most likely root cause.",
            f"Mitigation was applied: {remediation_history[-1]}.",
        ],
        "impact": (
            f"Customers experienced elevated failures or latency in {service_summary} until the incident was mitigated. "
            "The responder used the available evidence to reduce risk and restore service health."
        ),
        "rca": cause,
        "action_items": [
            "Add stronger pre-deployment safety checks for production-impacting changes.",
            "Improve alert-to-remediation guardrails so similar incidents recover faster.",
        ],
    }


def build_client() -> str | None:
    base_url = API_BASE_URL.strip()
    if not base_url or not HF_API_TOKEN.strip():
        return None
    return base_url.rstrip("/")


def call_model(client: str | None, observation: Dict[str, Any]) -> Dict[str, Any]:
    if not client:
        raise RuntimeError("No Hugging Face model backend configured.")

    prompt = (
        "You are solving a deterministic incident-response RL task. "
        "Return exactly one JSON object with keys action_type and payload. "
        "Allowed action_type values: classify_alert, query_logs, set_hypothesis, issue_remediation, write_postmortem. "
        "Payload schema is strict. "
        "For classify_alert use {'id': '<alert id>', 'label': 'symptom|cause|noise'}. "
        "For query_logs use {'keyword': '<term>'}. "
        "For set_hypothesis use {'cause': '<root cause>'}. "
        "For issue_remediation use {'command': '<safe command>'}. "
        "For write_postmortem use {'timeline': ['...','...','...'], 'impact': '<long text>', 'rca': '<root cause>', 'action_items': ['...','...']}. "
        "Prioritize safe remediation. Observation JSON follows:\n"
        f"{json.dumps(observation, ensure_ascii=True)}"
    )

    response = requests.post(
        f"{client}/chat/completions",
        json={
            "model": MODEL_NAME,
            "stream": False,
            "temperature": 0,
            "response_format": {"type": "json_object"},
            "messages": [
                {"role": "system", "content": "Return strict JSON only."},
                {"role": "user", "content": prompt},
            ],
        },
        headers={
            "Authorization": f"Bearer {HF_API_TOKEN.strip()}",
            "Content-Type": "application/json",
        },
        timeout=MODEL_TIMEOUT,
    )
    response.raise_for_status()
    payload = response.json()
    choices = payload.get("choices", [])
    message = choices[0].get("message", {}) if choices else {}
    content = message.get("content", "{}")
    parsed = json.loads(content)
    if "action_type" not in parsed or "payload" not in parsed:
        raise ValueError("Model response missing action_type or payload.")
    return parsed


def normalize_action(action: Dict[str, Any], observation: Dict[str, Any]) -> Dict[str, Any]:
    alerts = observation.get("alerts", [])
    valid_alert_ids = {alert["id"] for alert in alerts if "id" in alert}
    action_type = action.get("action_type")
    payload = action.get("payload")

    if not isinstance(action_type, str) or not isinstance(payload, dict):
        raise ValueError("Model response action_type/payload has invalid types.")

    if action_type == "classify_alert":
        alert_id = payload.get("id") or payload.get("alert_id")
        label = payload.get("label")

        if not isinstance(alert_id, str) or alert_id not in valid_alert_ids:
            raise ValueError("classify_alert requires a valid alert id.")

        if not isinstance(label, str):
            severity = str(payload.get("severity", "")).lower()
            if severity == "info":
                label = "noise"
            elif any(token in str(payload.get("message", "")).lower() for token in ["deploy", "timeout", "cpu", "memory", "query", "backfill", "certificate", "retry"]):
                label = "cause"
            else:
                label = "symptom"

        label = label.lower().strip()
        if label not in {"symptom", "cause", "noise"}:
            raise ValueError("classify_alert label must be symptom, cause, or noise.")

        return {"action_type": "classify_alert", "payload": {"id": alert_id, "label": label}}

    if action_type == "query_logs":
        keyword = payload.get("keyword")
        if not isinstance(keyword, str) or not keyword.strip():
            raise ValueError("query_logs requires a keyword.")
        return {"action_type": "query_logs", "payload": {"keyword": keyword.strip()}}

    if action_type == "set_hypothesis":
        cause = payload.get("cause") or payload.get("rca")
        if not isinstance(cause, str) or not cause.strip():
            raise ValueError("set_hypothesis requires a cause.")
        return {"action_type": "set_hypothesis", "payload": {"cause": cause.strip()}}

    if action_type == "issue_remediation":
        command = payload.get("command")
        if not isinstance(command, str) or not command.strip():
            raise ValueError("issue_remediation requires a command.")
        return {"action_type": "issue_remediation", "payload": {"command": command.strip()}}

    if action_type == "write_postmortem":
        timeline = payload.get("timeline")
        impact = payload.get("impact")
        rca = payload.get("rca")
        action_items = payload.get("action_items")
        if not isinstance(timeline, list) or not isinstance(action_items, list):
            raise ValueError("write_postmortem requires timeline and action_items lists.")
        if not isinstance(impact, str) or not isinstance(rca, str):
            raise ValueError("write_postmortem requires impact and rca strings.")
        return {
            "action_type": "write_postmortem",
            "payload": {
                "timeline": timeline,
                "impact": impact,
                "rca": rca,
                "action_items": action_items,
            },
        }

    raise ValueError(f"Unsupported action_type: {action_type}")


def heuristic_action(
    observation: Dict[str, Any],
    classified_ids: set[str] | None = None,
    previous_actions: list[Dict[str, Any]] | None = None,
) -> Dict[str, Any]:
    alerts = observation.get("alerts", [])
    classified_ids = classified_ids or set()
    previous_actions = previous_actions or []
    classifications = {
        action["payload"]["id"]: action["payload"]["label"]
        for action in previous_actions
        if action.get("action_type") == "classify_alert"
        and isinstance(action.get("payload", {}).get("id"), str)
        and isinstance(action.get("payload", {}).get("label"), str)
    }

    # Spend the early steps building a stronger triage score with balanced labels.
    if len(classified_ids) < 6:
        alert = select_next_alert_to_classify(alerts, classified_ids, classifications)
        if alert is not None:
            return {
                "action_type": "classify_alert",
                "payload": {"id": alert["id"], "label": classify_alert_from_text(alert)},
            }

    if observation["task"] == "full_resolution" and observation.get("remediation_history"):
        return {
            "action_type": "write_postmortem",
            "payload": build_postmortem(observation),
        }

    queried_keywords = {
        canonicalize(str(action.get("payload", {}).get("keyword", "")))
        for action in previous_actions
        if action.get("action_type") == "query_logs"
    }
    if len(observation.get("visible_logs", [])) <= 2 and not observation.get("active_hypothesis") and len(classified_ids) < 3:
        query_terms = (
            "deploy",
            "certificate",
            "backfill",
            "query",
            "cache",
            "heap",
            "oom",
            "retry",
            "timeout",
            "circuit",
        )
        combined_alert_text = canonicalize(" ".join(str(alert.get("message", "")) for alert in alerts))
        for term in query_terms:
            if term in combined_alert_text and canonicalize(term) not in queried_keywords:
                return {"action_type": "query_logs", "payload": {"keyword": term}}
        if "error" not in queried_keywords:
            return {"action_type": "query_logs", "payload": {"keyword": "error"}}

    if not observation.get("active_hypothesis"):
        return {"action_type": "set_hypothesis", "payload": {"cause": infer_root_cause(observation)}}
    if observation["task"] == "full_resolution" and not observation.get("remediation_history"):
        return {"action_type": "issue_remediation", "payload": {"command": infer_remediation(observation)}}
    if observation["task"] == "full_resolution":
        return {"action_type": "write_postmortem", "payload": build_postmortem(observation)}
    alert = select_next_alert_to_classify(alerts, classified_ids, classifications)
    if alert is not None:
        return {
            "action_type": "classify_alert",
            "payload": {"id": alert["id"], "label": classify_alert_from_text(alert)},
        }
    if "error" not in queried_keywords:
        return {"action_type": "query_logs", "payload": {"keyword": "error"}}
    return {"action_type": "set_hypothesis", "payload": {"cause": infer_root_cause(observation)}}


def is_stagnant_action(action: Dict[str, Any], previous_actions: list[Dict[str, Any]]) -> bool:
    if not previous_actions:
        return False

    if action == previous_actions[-1]:
        return True

    action_type = action.get("action_type")
    if action_type == "set_hypothesis":
        cause = action.get("payload", {}).get("cause")
        if not isinstance(cause, str):
            return True
        already_sent = {
            prev.get("payload", {}).get("cause")
            for prev in previous_actions
            if prev.get("action_type") == "set_hypothesis"
        }
        return cause in already_sent

    if action_type == "classify_alert":
        payload = action.get("payload", {})
        alert_id = payload.get("id")
        if not isinstance(alert_id, str):
            return True
        already_sent = {
            prev.get("payload", {}).get("id")
            for prev in previous_actions
            if prev.get("action_type") == "classify_alert"
        }
        return alert_id in already_sent

    if action_type == "query_logs":
        keyword = action.get("payload", {}).get("keyword")
        if not isinstance(keyword, str):
            return True
        normalized_keyword = canonicalize(keyword)
        already_sent = {
            canonicalize(str(prev.get("payload", {}).get("keyword", "")))
            for prev in previous_actions
            if prev.get("action_type") == "query_logs"
        }
        return normalized_keyword in already_sent

    if action_type == "issue_remediation":
        command = action.get("payload", {}).get("command")
        if not isinstance(command, str):
            return True
        normalized_command = canonicalize(command)
        already_sent = {
            canonicalize(str(prev.get("payload", {}).get("command", "")))
            for prev in previous_actions
            if prev.get("action_type") == "issue_remediation"
        }
        return normalized_command in already_sent

    if action_type == "write_postmortem":
        return any(prev.get("action_type") == "write_postmortem" for prev in previous_actions)

    return False


def select_action(
    client: str | None,
    observation: Dict[str, Any],
    previous_actions: list[Dict[str, Any]],
    classified_ids: set[str],
) -> Dict[str, Any]:
    try:
        action = normalize_action(call_model(client, observation), observation)
        if is_stagnant_action(action, previous_actions):
            return heuristic_action(observation, classified_ids, previous_actions)
        return action
    except Exception:
        return heuristic_action(observation, classified_ids, previous_actions)


def main() -> None:
    client = build_client()
    reset_payload = {"task": "full_resolution", "max_steps": MAX_STEPS, "seed": RUN_SEED}
    try:
        reset_response = requests.post(f"{DEFAULT_ENV_URL}/reset", json=reset_payload, timeout=30)
        reset_response.raise_for_status()
    except RequestException as exc:
        raise SystemExit(
            "Could not reach the incident environment API.\n"
            f"Expected server: {DEFAULT_ENV_URL}\n"
            "Start it first with:\n"
            "  uvicorn incident_review_env.server.app:app --host 0.0.0.0 --port 7860\n"
            "Or point inference.py at a different server with ENV_BASE_URL.\n"
            f"Original error: {exc}"
        ) from exc

    state = reset_response.json()
    observation = state["observation"]
    task = observation["task"]

    rewards: list[float] = [float(state["reward"]["total"])]
    success = False
    done = False
    steps_taken = 0
    action_history: list[Dict[str, Any]] = []
    classified_ids: set[str] = set()

    backend_label = client or "heuristic-only"
    print(f"[START] task={task} env=incident-review-env model={MODEL_NAME} backend={backend_label} seed={RUN_SEED}")

    for step_index in range(1, MAX_STEPS + 1):
        error_value = "None"
        try:
            action = select_action(client, observation, action_history, classified_ids)
            if action["action_type"] == "classify_alert":
                classified_ids.add(action["payload"]["id"])
            action_history.append(action)
            step_response = requests.post(f"{DEFAULT_ENV_URL}/step", json=action, timeout=30)
            step_response.raise_for_status()
            payload = step_response.json()
            reward_value = float(payload["reward"]["total"])
            done = bool(payload["done"])
            rewards.append(reward_value)
            steps_taken = step_index
            observation = payload["observation"]
            success = done and reward_value >= SUCCESS_THRESHOLD
            print(
                f"[STEP] step={step_index} action={json.dumps(action, ensure_ascii=True)} "
                f"reward={reward_value:.4f} done={done} error={error_value}"
            )
            if done:
                break
        except Exception as exc:
            error_value = str(exc).replace("\n", " ")
            print(
                f"[STEP] step={step_index} action={json.dumps({'action_type': 'error', 'payload': {}}, ensure_ascii=True)} "
                f"reward=0.0000 done=False error={error_value}"
            )
            steps_taken = step_index
            break

    score = rewards[-1] if rewards else 0.0
    print(f"[END] success={success} steps={steps_taken} score={score:.4f} rewards={json.dumps(rewards)}")


if __name__ == "__main__":
    main()
