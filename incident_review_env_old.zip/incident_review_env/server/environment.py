from __future__ import annotations

import copy
import random
from typing import Any, Dict, Optional

from incident_review_env.graders.postmortem_grader import grade_postmortem
from incident_review_env.graders.rca_grader import grade_rca
from incident_review_env.graders.triage_grader import grade_triage
from incident_review_env.models import Action, AlertRecord, EnvState, Observation, Reward, TaskType
from incident_review_env.scenarios import ALL_SCENARIOS
from incident_review_env.scenarios.base import Scenario
from incident_review_env.server.tasks import TASK_HINTS
from incident_review_env.utils import clamp, contains_any, is_unsafe_command, unique_preserve_order


class IncidentReviewEnv:
    def __init__(self, seed: int = 42, max_steps: int = 8) -> None:
        self.random = random.Random(seed)
        self.max_steps = max_steps
        self.current_scenario: Optional[Scenario] = None
        self.current_task: TaskType = "alert_triage"
        self.step_count = 0
        self.classifications: Dict[str, str] = {}
        self.hypothesis: Optional[str] = None
        self.postmortem: Optional[Dict[str, Any]] = None
        self.remediation_history: list[str] = []
        self.remediation_success = False
        self.visible_logs: list[str] = []
        self.metrics: Dict[str, float] = {}
        self.penalty_total = 0.0
        self.degraded = False
        self.done = False
        self.last_reward = Reward(total=0.0, triage=0.0, rca=0.0, postmortem=0.0, efficiency=1.0, penalty=0.0)

    def reset(self, task: Optional[TaskType] = None) -> Observation:
        self.current_scenario = copy.deepcopy(self.random.choice(ALL_SCENARIOS))
        self.current_task = task or self.random.choice(["alert_triage", "root_cause", "full_resolution"])
        self.step_count = 0
        self.classifications = {}
        self.hypothesis = None
        self.postmortem = None
        self.remediation_history = []
        self.remediation_success = False
        self.visible_logs = self.current_scenario.logs[:2]
        self.metrics = dict(self.current_scenario.metrics)
        self.penalty_total = 0.0
        self.degraded = False
        self.done = False
        self.last_reward = self._compute_reward()
        return self._observation()

    def step(self, action: Action) -> tuple[Observation, Reward, bool, Dict[str, Any]]:
        if self.current_scenario is None:
            raise RuntimeError("Environment must be reset before stepping.")

        if self.done:
            return self._observation(), self.last_reward, True, {"message": "Episode already finished."}

        self.step_count += 1
        info: Dict[str, Any] = {"action_type": action.action_type}

        handler = getattr(self, f"_handle_{action.action_type}", None)
        if handler is None:
            info["error"] = f"Unsupported action type: {action.action_type}"
        else:
            info.update(handler(action.payload))

        self.last_reward = self._compute_reward()
        self.done = self._check_done()
        if self.step_count >= self.max_steps:
            self.done = True
            info.setdefault("message", "Max steps reached.")

        return self._observation(), self.last_reward, self.done, info

    def state(self) -> EnvState:
        if self.current_scenario is None:
            raise RuntimeError("Environment must be reset before state inspection.")

        return EnvState(
            task=self.current_task,
            step_count=self.step_count,
            max_steps=self.max_steps,
            scenario_id=self.current_scenario.scenario_id,
            scenario_title=self.current_scenario.title,
            scenario_root_cause=self.current_scenario.root_cause,
            alerts=[AlertRecord(**alert) for alert in self.current_scenario.alerts],
            visible_logs=list(self.visible_logs),
            all_logs=list(self.current_scenario.logs),
            metrics=dict(self.metrics),
            ground_truth_alert_labels=dict(self.current_scenario.ground_truth_alert_labels),
            classifications=dict(self.classifications),
            hypothesis=self.hypothesis,
            remediation_history=list(self.remediation_history),
            remediation_success=self.remediation_success,
            postmortem=self.postmortem,
            reward=self.last_reward,
            degraded=self.degraded,
            done=self.done,
        )

    def _observation(self) -> Observation:
        assert self.current_scenario is not None
        return Observation(
            task=self.current_task,
            step_count=self.step_count,
            max_steps=self.max_steps,
            scenario_id=self.current_scenario.scenario_id,
            scenario_title=self.current_scenario.title,
            alerts=[AlertRecord(**alert) for alert in self.current_scenario.alerts],
            visible_logs=list(self.visible_logs),
            metrics=dict(self.metrics),
            active_hypothesis=self.hypothesis,
            remediation_history=list(self.remediation_history),
            postmortem_submitted=self.postmortem is not None,
            partial_scores={
                "triage": self.last_reward.triage,
                "rca": self.last_reward.rca,
                "postmortem": self.last_reward.postmortem,
                "efficiency": self.last_reward.efficiency,
            },
            hints=TASK_HINTS[self.current_task],
            degraded=self.degraded,
        )

    def _compute_reward(self) -> Reward:
        assert self.current_scenario is not None

        triage_score = grade_triage(self.current_scenario.ground_truth_alert_labels, self.classifications)
        rca_score = grade_rca(self.hypothesis, self.current_scenario.root_cause, self.current_scenario.aliases)
        postmortem_score = grade_postmortem(self.postmortem, self.current_scenario.root_cause, self.current_scenario.action_items)
        efficiency_score = clamp(1.0 - (self.step_count / max(1, self.max_steps)))

        total = (
            (0.30 * triage_score)
            + (0.30 * rca_score)
            + (0.30 * postmortem_score)
            + (0.10 * efficiency_score)
        )
        total = clamp(total - self.penalty_total)
        return Reward(
            total=total,
            triage=triage_score,
            rca=rca_score,
            postmortem=postmortem_score,
            efficiency=efficiency_score,
            penalty=self.penalty_total,
        )

    def _check_done(self) -> bool:
        assert self.current_scenario is not None

        if self.current_task == "alert_triage":
            return len(self.classifications) >= len(self.current_scenario.ground_truth_alert_labels)
        if self.current_task == "root_cause":
            return self.last_reward.triage >= 0.7 and self.last_reward.rca >= 0.5
        return self.remediation_success and self.postmortem is not None

    def _handle_classify_alert(self, payload: Dict[str, Any]) -> Dict[str, Any]:
        assert self.current_scenario is not None
        alert_id = str(payload.get("id", "")).strip()
        label = str(payload.get("label", "")).strip().lower()

        valid_ids = {alert["id"] for alert in self.current_scenario.alerts}
        valid_labels = {"symptom", "cause", "noise"}
        if alert_id not in valid_ids:
            return {"error": f"Unknown alert id: {alert_id}"}
        if label not in valid_labels:
            return {"error": f"Invalid label: {label}"}

        self.classifications[alert_id] = label
        return {"classified": {alert_id: label}}

    def _handle_query_logs(self, payload: Dict[str, Any]) -> Dict[str, Any]:
        assert self.current_scenario is not None
        keyword = str(payload.get("keyword", "")).strip()
        if not keyword:
            return {"error": "query_logs requires a keyword."}

        keyword_lower = keyword.lower()
        matched = [entry for entry in self.current_scenario.logs if keyword_lower in entry.lower()]
        if matched:
            self.visible_logs = unique_preserve_order([*self.visible_logs, *matched])
            if contains_any(keyword_lower, self.current_scenario.log_hints):
                self.metrics["latency"] = max(50.0, self.metrics["latency"] * 0.97)
            return {"log_results": matched}
        return {"log_results": [], "message": "No logs matched the requested keyword."}

    def _handle_set_hypothesis(self, payload: Dict[str, Any]) -> Dict[str, Any]:
        cause = str(payload.get("cause", "")).strip()
        if not cause:
            return {"error": "set_hypothesis requires a cause."}
        self.hypothesis = cause
        return {"hypothesis": self.hypothesis}

    def _handle_issue_remediation(self, payload: Dict[str, Any]) -> Dict[str, Any]:
        assert self.current_scenario is not None
        command = str(payload.get("command", "")).strip()
        if not command:
            return {"error": "issue_remediation requires a command."}

        self.remediation_history.append(command)
        if is_unsafe_command(command):
            self.penalty_total = clamp(self.penalty_total + 0.1)
            self.degraded = True
            self.metrics["latency"] *= 1.15
            self.metrics["memory"] = clamp(self.metrics["memory"] + 6.0, 0.0, 100.0)
            self.metrics["cpu"] = clamp(self.metrics["cpu"] + 4.0, 0.0, 100.0)
            return {"unsafe": True, "message": "Unsafe remediation worsened the incident."}

        normalized = command.lower()
        if any(allowed in normalized for allowed in self.current_scenario.remediation_commands):
            self.remediation_success = True
            self.metrics["latency"] = max(80.0, self.metrics["latency"] * 0.45)
            self.metrics["cpu"] = max(15.0, self.metrics["cpu"] * 0.6)
            self.metrics["memory"] = max(20.0, self.metrics["memory"] * 0.75)
            return {"unsafe": False, "message": "Remediation applied successfully."}

        self.metrics["latency"] *= 1.03
        return {"unsafe": False, "message": "Command recorded but had limited effect."}

    def _handle_write_postmortem(self, payload: Dict[str, Any]) -> Dict[str, Any]:
        timeline = payload.get("timeline")
        impact = payload.get("impact")
        rca = payload.get("rca")
        action_items = payload.get("action_items")

        if not isinstance(timeline, list) or not isinstance(action_items, list):
            return {"error": "timeline and action_items must be lists."}

        self.postmortem = {
            "timeline": timeline,
            "impact": str(impact or ""),
            "rca": str(rca or ""),
            "action_items": action_items,
        }
        return {"postmortem_received": True}
