from __future__ import annotations

from incident_review_env.scenarios import ALL_SCENARIOS


TASKS = {
    "alert_triage": "Classify alerts into symptom, cause, or noise.",
    "root_cause": "Investigate evidence and identify the most likely root cause.",
    "full_resolution": "Triage alerts, identify root cause, remediate safely, and submit a postmortem.",
}
TASK_HINTS = {
    "alert_triage": ["Classify alerts into symptom, cause, or noise."],
    "root_cause": ["Classify signals, inspect logs, and set the most likely root cause."],
    "full_resolution": ["Complete triage, identify root cause, remediate safely, and submit a postmortem."],
}


def list_tasks() -> dict[str, str]:
    return dict(TASKS)


def list_scenarios() -> list[dict[str, str]]:
    return [
        {
            "scenario_id": scenario.scenario_id,
            "title": scenario.title,
            "service": scenario.service,
            "summary": scenario.summary,
        }
        for scenario in ALL_SCENARIOS
    ]
