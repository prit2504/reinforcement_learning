from __future__ import annotations

import io
import os
import unittest
from contextlib import redirect_stdout

from fastapi.testclient import TestClient

import incident_review_env.inference as inference
from incident_review_env.server import app


class _ShimResponse:
    def __init__(self, response) -> None:
        self._response = response

    def raise_for_status(self) -> None:
        self._response.raise_for_status()

    def json(self):
        return self._response.json()


class IncidentReviewSmokeTests(unittest.TestCase):
    def setUp(self) -> None:
        self.client = TestClient(app)

    def test_health_reset_step_and_state(self) -> None:
        health = self.client.get("/health")
        self.assertEqual(health.status_code, 200)
        self.assertEqual(health.json(), {"status": "ok"})

        reset = self.client.post("/reset", json={"task": "full_resolution", "seed": 42})
        self.assertEqual(reset.status_code, 200)
        observation = reset.json()["observation"]

        action = {
            "action_type": "classify_alert",
            "payload": {"id": observation["alerts"][0]["id"], "label": "symptom"},
        }
        step = self.client.post("/step", json=action)
        self.assertEqual(step.status_code, 200)
        self.assertIn("action_type", step.json()["info"])

        state = self.client.get("/state")
        self.assertEqual(state.status_code, 200)
        self.assertEqual(state.json()["step_count"], 1)

    def test_reset_accepts_custom_max_steps(self) -> None:
        reset = self.client.post("/reset", json={"task": "full_resolution", "seed": 42, "max_steps": 10})
        self.assertEqual(reset.status_code, 200)
        observation = reset.json()["observation"]
        self.assertEqual(observation["max_steps"], 10)

    def test_seeded_reset_is_repeatable(self) -> None:
        first = self.client.post("/reset", json={"task": "full_resolution", "seed": 42, "max_steps": 10}).json()["observation"]
        second = self.client.post("/reset", json={"task": "full_resolution", "seed": 42, "max_steps": 10}).json()["observation"]
        self.assertEqual(first["scenario_id"], second["scenario_id"])

    def test_inference_heuristic_run_completes(self) -> None:
        original_api_base = os.environ.get("API_BASE_URL")
        os.environ["API_BASE_URL"] = ""

        original_base_url = inference.DEFAULT_ENV_URL
        original_api_url = inference.API_BASE_URL
        original_post = inference.requests.post

        def fake_post(url, json=None, timeout=None):
            if url.endswith("/reset"):
                return _ShimResponse(self.client.post("/reset", json=json))
            if url.endswith("/step"):
                return _ShimResponse(self.client.post("/step", json=json))
            raise RuntimeError(f"Unexpected URL: {url}")

        inference.DEFAULT_ENV_URL = "http://testserver"
        inference.API_BASE_URL = ""
        inference.requests.post = fake_post

        try:
            output = io.StringIO()
            with redirect_stdout(output):
                inference.main()
        finally:
            inference.DEFAULT_ENV_URL = original_base_url
            inference.API_BASE_URL = original_api_url
            inference.requests.post = original_post
            if original_api_base is None:
                os.environ.pop("API_BASE_URL", None)
            else:
                os.environ["API_BASE_URL"] = original_api_base

        stdout = output.getvalue()
        self.assertIn("[START]", stdout)
        self.assertIn("[END]", stdout)
        self.assertIn("seed=42", stdout)
        self.assertIn("steps=", stdout)
        self.assertIn("score=", stdout)

    def test_heuristic_does_not_repeat_same_log_query_forever(self) -> None:
        observation = {
            "task": "full_resolution",
            "scenario_id": "bad_deploy",
            "alerts": [
                {"id": "C01", "severity": "critical", "message": "Auth error rate above 18%", "service": "auth-service"},
                {"id": "C02", "severity": "critical", "message": "TLS handshake failures above 500/min", "service": "auth-service"},
                {"id": "C04", "severity": "warning", "message": "Deployment completed 6m ago", "service": "auth-service"},
            ],
            "visible_logs": [
                "2026-04-06T08:40:16Z auth-service app[55]: ERROR x509: certificate signed by unknown authority while connecting to idp.internal",
                "2026-04-06T08:40:31Z auth-service deploy[11]: applied config bundle auth-service-config-v184",
            ],
            "active_hypothesis": None,
            "remediation_history": [],
        }
        previous_actions = [{"action_type": "query_logs", "payload": {"keyword": "deploy"}}]

        action = inference.heuristic_action(observation, classified_ids={"C16", "C02", "C04", "C05"}, previous_actions=previous_actions)
        self.assertNotEqual(action, previous_actions[-1])
        self.assertIn(action["action_type"], {"classify_alert", "query_logs", "set_hypothesis"})


if __name__ == "__main__":
    unittest.main()
