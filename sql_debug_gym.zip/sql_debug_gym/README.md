# SQL Debug Gym

An OpenEnv-style reinforcement learning environment where agents debug broken SQL queries and ETL pipelines.

## Overview

SQL Debug Gym simulates common data-engineering debugging work. An agent receives a broken SQL artifact, explores a SQLite database, and submits a corrected query or pipeline.

Rewards combine:
- correctness (0.0-0.6)
- efficiency (0.0-0.2)
- progress (0.0-0.2)
- step execution bonus (+0.02 per successful step)

## Action Space

```python
class SqlDebugAction(BaseModel):
    query: str
    explanation: str
    submit: bool
```

## Observation Space

```python
class SqlDebugObservation(BaseModel):
    task_name: str
    task_description: str
    schema: str
    broken_artifact: str
    last_query: str
    execution_result: str
    hint: str
    step_number: int
    max_steps: int
    done: bool
    error: str
```

## Tasks

1. `fix_broken_join` (easy)
2. `debug_etl_pipeline` (medium)
3. `optimize_slow_query` (hard)

## Local Setup (No Docker)

```bash
pip install -r sql_debug_gym/server/requirements.txt

# start API server
uvicorn sql_debug_gym.server.app:app --host 0.0.0.0 --port 7860 --reload
```

## Inference with Ollama URL

Use any OpenAI-compatible Ollama endpoint.

```bash
# Windows PowerShell
$env:SQL_GYM_BASE_URL="http://localhost:7860"
$env:OLLAMA_BASE_URL="http://localhost:11434/v1"
$env:MODEL_NAME="llama3.1:8b"
$env:API_KEY="ollama"
python -m sql_debug_gym.inference
```

## API

- `GET /health`
- `POST /reset`
- `POST /step`
- `GET /state`
- `WS /ws`
- `GET /web`
- `GET /docs`

## Project Structure

```text
sql_debug_gym/
|-- __init__.py
|-- models.py
|-- client.py
|-- inference.py
|-- openenv.yaml
|-- pyproject.toml
|-- README.md
`-- server/
    |-- __init__.py
    |-- app.py
    |-- environment.py
    |-- tasks.py
    `-- requirements.txt
```

## Environment Variables

- `SQL_GYM_BASE_URL` default `http://localhost:7860`
- `SQL_DEBUG_TASK` default `fix_broken_join`
- `OLLAMA_BASE_URL` default `http://localhost:11434/v1`
- `MODEL_NAME` default `llama3.1:8b`
- `API_KEY` default `ollama`
