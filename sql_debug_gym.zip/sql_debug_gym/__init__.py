"""SQL Debug Gym package."""

from .models import SqlDebugAction, SqlDebugObservation, SqlDebugReward, StepResponse

try:
    from .client import SqlDebugEnv
except Exception:  # pragma: no cover - optional during partial installs
    SqlDebugEnv = None  # type: ignore[assignment]

__all__ = [
    "SqlDebugEnv",
    "SqlDebugAction",
    "SqlDebugObservation",
    "SqlDebugReward",
    "StepResponse",
]
