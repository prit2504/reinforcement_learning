﻿from __future__ import annotations

import json
import os
from typing import Any

import httpx

from sql_debug_gym.client import SqlDebugEnv
from sql_debug_gym.models import SqlDebugAction, SqlDebugObservation

SYSTEM_PROMPT = """You are a SQL debugging agent.
Return strict JSON with fields: query (string), explanation (string), submit (boolean).
Rules:
- Use valid SQLite SQL.
- First run exploratory queries if needed.
- Submit only when confident.
- Never include markdown fences.
"""


def _extract_json(text: str) -> dict[str, Any]:
    text = text.strip()
    if text.startswith("{") and text.endswith("}"):
        return json.loads(text)
    start = text.find("{")
    end = text.rfind("}")
    if start >= 0 and end > start:
        return json.loads(text[start : end + 1])
    raise ValueError("Model response did not contain JSON object.")


def _build_user_prompt(obs: SqlDebugObservation) -> str:
    return f"""
Task: {obs.task_name}
Description: {obs.task_description}
Max steps: {obs.max_steps}
Current step: {obs.step_number}
Hint: {obs.hint}

Schema and sample data:
{obs.schema_text}

Broken artifact:
{obs.broken_artifact}

Last query:
{obs.last_query}

Last execution result:
{obs.execution_result}

Return only JSON with query, explanation, submit.
""".strip()


def fetch_available_tasks(base_env_url: str, timeout: float = 30.0) -> list[str]:
    url = f"{base_env_url.rstrip('/')}/health"
    with httpx.Client(timeout=timeout) as client:
        resp = client.get(url)
        resp.raise_for_status()
        data = resp.json()
    tasks = data.get("tasks", [])
    return [str(task) for task in tasks]


def choose_task(base_env_url: str) -> str:
    env_task = os.getenv("SQL_DEBUG_TASK")
    if env_task:
        return env_task

    try:
        tasks = fetch_available_tasks(base_env_url)
    except Exception:
        tasks = ["fix_broken_join", "debug_etl_pipeline", "optimize_slow_query"]

    print("Available tasks:")
    for index, task in enumerate(tasks, start=1):
        print(f"  {index}. {task}")

    selected = input("Enter task name or number [fix_broken_join]: ").strip()
    if not selected:
        return "fix_broken_join"
    if selected.isdigit():
        idx = int(selected) - 1
        if 0 <= idx < len(tasks):
            return tasks[idx]
    return selected


def call_ollama_chat(
    base_url: str,
    model: str,
    observation: SqlDebugObservation,
    api_key: str | None = None,
    timeout: float = 120.0,
    
) -> SqlDebugAction:
    url = f"{base_url.rstrip('/')}/chat/completions"
    payload = {
        "model": model,
        "temperature": 0.1,
        "messages": [
            {"role": "system", "content": SYSTEM_PROMPT},
            {"role": "user", "content": _build_user_prompt(observation)},
        ],
        "response_format": {"type": "json_object"},
    }
    headers: dict[str, str] = {}
    if api_key:
        headers["Authorization"] = f"Bearer {api_key}"

    with httpx.Client(timeout=timeout) as client:
        resp = client.post(url, headers=headers or None, json=payload)
        resp.raise_for_status()
        data = resp.json()

    content = data["choices"][0]["message"]["content"]
    parsed = _extract_json(content)
    return SqlDebugAction(
        query=parsed.get("query", "SELECT 1;"),
        explanation=parsed.get("explanation", ""),
        submit=bool(parsed.get("submit", False)),
    )


def run_episode() -> None:
    base_env_url = os.getenv("SQL_GYM_BASE_URL", "http://localhost:7860")
    ollama_base_url = os.getenv("OLLAMA_BASE_URL", "http://nav0357:19434/v1")
    model_name = os.getenv("MODEL_NAME", "llama3.1:8b")
    api_key = os.getenv("API_KEY")
    task_name = choose_task(base_env_url)

    env = SqlDebugEnv(base_url=base_env_url)
    try:
        obs = env.reset(task_name=task_name)
        print(f"Task: {obs.task_name}")
        print(f"Description: {obs.task_description}")

        while not obs.done:
            action = call_ollama_chat(
                base_url=ollama_base_url,
                model=model_name,
                observation=obs,
                api_key=api_key,
            )
            print("\nGenerated SQL:")
            print(action.query)
            if action.explanation:
                print("\nModel explanation:")
                print(action.explanation)

            step = env.step(action)
            obs = step.observation
            print(
                f"step={obs.step_number} submit={action.submit} "
                f"reward={step.reward.total} done={obs.done}"
            )
            print(f"result: {obs.execution_result}")
            if obs.done:
                print("Final reward:", step.reward.model_dump())
                break
    finally:
        env.close()


if __name__ == "__main__":
    run_episode()
