from __future__ import annotations

import sqlite3
from dataclasses import dataclass
from typing import Callable, List, Sequence, Tuple

from sql_debug_gym.models import SqlDebugReward

Rows = List[Tuple]


@dataclass(frozen=True)
class TaskSpec:
    name: str
    description: str
    schema_sql: str
    seed_sql: str
    broken_artifact: str
    hints: List[str]
    max_steps: int
    expected_query: str
    grader: Callable[[str, str, int, int], SqlDebugReward]

    @property
    def full_schema(self) -> str:
        return f"{self.schema_sql}\n\n{self.seed_sql}".strip()


def _normalize_rows(rows: Sequence[Tuple]) -> Rows:
    return [tuple("" if c is None else str(c) for c in row) for row in rows]


def _safe_execute_query(conn: sqlite3.Connection, query: str) -> Rows:
    cur = conn.cursor()
    cur.execute(query)
    rows = cur.fetchall()
    return _normalize_rows(rows)


def _jaccard_like_score(predicted: Rows, expected: Rows) -> float:
    if not expected and not predicted:
        return 1.0
    p = set(predicted)
    e = set(expected)
    intersection = len(p.intersection(e))
    union = max(1, len(p.union(e)))
    return intersection / union


def _efficiency_score(step_number: int, max_steps: int) -> float:
    extra_steps = max(0, step_number - 3)
    span = max(1, max_steps - 3)
    return max(0.0, 1.0 - (extra_steps / span))


def _generic_grader(task_name: str, submission_query: str, step_number: int, max_steps: int) -> SqlDebugReward:
    task = TASKS[task_name]
    conn = sqlite3.connect(":memory:")
    try:
        conn.executescript(task.schema_sql)
        conn.executescript(task.seed_sql)

        expected_rows = _safe_execute_query(conn, task.expected_query)

        # For pipeline task we allow scripts and then compare clean table.
        if task_name == "debug_etl_pipeline":
            conn.executescript("DELETE FROM clean_sales;")
            conn.executescript(submission_query)
            predicted_rows = _safe_execute_query(
                conn,
                "SELECT sale_date, product, quantity, unit_price, revenue, region FROM clean_sales ORDER BY sale_date, product;",
            )
        else:
            predicted_rows = _safe_execute_query(conn, submission_query)

        correctness = _jaccard_like_score(predicted_rows, expected_rows)
        progress = correctness
        efficiency = _efficiency_score(step_number, max_steps)

        return SqlDebugReward(
            total=round((0.6 * correctness) + (0.2 * efficiency) + (0.2 * progress), 4),
            correctness=round(0.6 * correctness, 4),
            efficiency=round(0.2 * efficiency, 4),
            progress=round(0.2 * progress, 4),
            step_bonus=0.0,
        )
    except Exception:
        efficiency = _efficiency_score(step_number, max_steps)
        return SqlDebugReward(
            total=round(0.2 * efficiency, 4),
            correctness=0.0,
            efficiency=round(0.2 * efficiency, 4),
            progress=0.0,
            step_bonus=0.0,
        )
    finally:
        conn.close()


def _fix_broken_join_grader(submission_query: str, task_name: str, step_number: int, max_steps: int) -> SqlDebugReward:
    return _generic_grader(task_name, submission_query, step_number, max_steps)


def _debug_etl_grader(submission_query: str, task_name: str, step_number: int, max_steps: int) -> SqlDebugReward:
    return _generic_grader(task_name, submission_query, step_number, max_steps)


def _optimize_query_grader(submission_query: str, task_name: str, step_number: int, max_steps: int) -> SqlDebugReward:
    return _generic_grader(task_name, submission_query, step_number, max_steps)


TASKS: dict[str, TaskSpec] = {
    "fix_broken_join": TaskSpec(
        name="fix_broken_join",
        description=(
            "Return each customer's name and total completed order amount. "
            "The broken query has three issues: wrong status value, typo in ORDER BY, and a subtle logic bug."
        ),
        schema_sql="""
CREATE TABLE customers (
    id INTEGER PRIMARY KEY,
    name TEXT NOT NULL,
    city TEXT NOT NULL
);

CREATE TABLE orders (
    id INTEGER PRIMARY KEY,
    customer_id INTEGER NOT NULL,
    amount REAL NOT NULL,
    status TEXT NOT NULL,
    FOREIGN KEY(customer_id) REFERENCES customers(id)
);
""".strip(),
        seed_sql="""
INSERT INTO customers (id, name, city) VALUES
    (1, 'Ava', 'Austin'),
    (2, 'Noah', 'Boston'),
    (3, 'Mia', 'Chicago'),
    (4, 'Liam', 'Denver');

INSERT INTO orders (id, customer_id, amount, status) VALUES
    (1, 1, 120.0, 'completed'),
    (2, 1, 80.0, 'pending'),
    (3, 2, 200.0, 'completed'),
    (4, 2, 50.0, 'cancelled'),
    (5, 3, 300.0, 'completed'),
    (6, 3, 60.0, 'completed');
""".strip(),
        broken_artifact="""
SELECT c.name, SUM(o.amount) AS total_amount
FROM customers c
LEFT JOIN orders o ON c.id = o.id
WHERE o.status = 'complete'
GROUP BY c.name
ORDER BY total_amunt DESC;
""".strip(),
        hints=[
            "Check whether the JOIN key matches customers to orders.",
            "Verify the status literal against data values.",
            "Look closely at aliases in ORDER BY.",
        ],
        max_steps=8,
        expected_query="""
SELECT c.name, SUM(o.amount) AS total_amount
FROM customers c
JOIN orders o ON c.id = o.customer_id
WHERE o.status = 'completed'
GROUP BY c.name
ORDER BY total_amount DESC;
""".strip(),
        grader=_fix_broken_join_grader,
    ),
    "debug_etl_pipeline": TaskSpec(
        name="debug_etl_pipeline",
        description=(
            "Load clean January 2024 sales from raw_sales (TEXT columns), cast numeric fields, "
            "filter invalid rows, compute revenue, and insert into clean_sales."
        ),
        schema_sql="""
CREATE TABLE raw_sales (
    sale_date TEXT,
    product TEXT,
    quantity TEXT,
    unit_price TEXT,
    region TEXT
);

CREATE TABLE clean_sales (
    sale_date TEXT,
    product TEXT,
    quantity INTEGER,
    unit_price REAL,
    revenue REAL,
    region TEXT
);
""".strip(),
        seed_sql="""
INSERT INTO raw_sales (sale_date, product, quantity, unit_price, region) VALUES
    ('2024-01-02', 'Widget', '2', '10.5', 'north'),
    ('2024-01-05', 'Gadget', '3', '20', 'west'),
    ('2024-01-15', 'Widget', 'bad', '11.0', 'north'),
    ('2024-01-21', 'Cable', '4', '5.25', 'south'),
    ('2024-02-01', 'Widget', '1', '10.5', 'north'),
    ('2024-01-11', 'Gadget', '-1', '20', 'west'),
    ('2024-01-18', 'Mouse', '5', '0', 'east'),
    ('2024-01-22', 'Cable', '2', 'oops', 'south');
""".strip(),
        broken_artifact="""
INSERT INTO clean_sales (sale_date, product, quantity, unit_price, revenue, region)
SELECT
    sale_date,
    product,
    CAST(quantity AS INTEGER) AS quantity,
    CAST(unit_price AS REAL) AS unit_price,
    CAST(quantity AS INTEGER) + CAST(unit_price AS REAL) AS revenue,
    region
FROM raw_sales
WHERE sale_date BETWEEN '2024-01-01' AND '2024-01-31'
  AND quantity > 0
  AND unit_price > 0;
""".strip(),
        hints=[
            "In SQLite, comparisons on TEXT can pass unexpected values.",
            "Revenue should be multiplication, not addition.",
            "Validate casts before filtering numeric constraints.",
        ],
        max_steps=10,
        expected_query="""
SELECT sale_date, product, quantity, unit_price, revenue, region
FROM (
    SELECT
        sale_date,
        product,
        CAST(quantity AS INTEGER) AS quantity,
        CAST(unit_price AS REAL) AS unit_price,
        CAST(quantity AS INTEGER) * CAST(unit_price AS REAL) AS revenue,
        region
    FROM raw_sales
    WHERE sale_date >= '2024-01-01'
      AND sale_date < '2024-02-01'
      AND quantity <> ''
      AND quantity NOT GLOB '*[^0-9]*'
      AND unit_price <> ''
      AND unit_price NOT GLOB '*[^0-9.]*'
      AND CAST(quantity AS INTEGER) > 0
      AND CAST(unit_price AS REAL) > 0
)
ORDER BY sale_date, product;
""".strip(),
        grader=_debug_etl_grader,
    ),
    "optimize_slow_query": TaskSpec(
        name="optimize_slow_query",
        description=(
            "Find top salesperson by total amount for each product category. "
            "The broken query is slow and logically wrong due to correlated subquery grouping."
        ),
        schema_sql="""
CREATE TABLE products (
    id INTEGER PRIMARY KEY,
    name TEXT NOT NULL,
    category TEXT NOT NULL
);

CREATE TABLE sales (
    id INTEGER PRIMARY KEY,
    product_id INTEGER NOT NULL,
    sale_date TEXT NOT NULL,
    amount REAL NOT NULL,
    salesperson TEXT NOT NULL,
    FOREIGN KEY(product_id) REFERENCES products(id)
);
""".strip(),
        seed_sql="""
INSERT INTO products (id, name, category) VALUES
    (1, 'Laptop A', 'electronics'),
    (2, 'Laptop B', 'electronics'),
    (3, 'Desk X', 'furniture'),
    (4, 'Chair Y', 'furniture');

INSERT INTO sales (id, product_id, sale_date, amount, salesperson) VALUES
    (1, 1, '2024-01-03', 1200, 'Alice'),
    (2, 2, '2024-01-04', 1500, 'Bob'),
    (3, 1, '2024-01-06', 900, 'Alice'),
    (4, 3, '2024-01-08', 400, 'Cara'),
    (5, 4, '2024-01-09', 250, 'Cara'),
    (6, 3, '2024-01-10', 800, 'Dan'),
    (7, 2, '2024-01-12', 700, 'Bob'),
    (8, 4, '2024-01-13', 300, 'Dan');
""".strip(),
        broken_artifact="""
SELECT p.category, s.salesperson, SUM(s.amount) AS total_sales
FROM sales s
JOIN products p ON p.id = s.product_id
WHERE s.amount = (
    SELECT MAX(s2.amount)
    FROM sales s2
    JOIN products p2 ON p2.id = s2.product_id
    WHERE p2.category = p.category
)
GROUP BY p.category, s.salesperson
ORDER BY total_sales DESC;
""".strip(),
        hints=[
            "You need top salesperson by SUM(amount), not max single sale.",
            "Pre-aggregate by category + salesperson first.",
            "Use CTE + window rank to avoid correlated subquery.",
        ],
        max_steps=10,
        expected_query="""
WITH totals AS (
    SELECT
        p.category,
        s.salesperson,
        SUM(s.amount) AS total_sales
    FROM sales s
    JOIN products p ON p.id = s.product_id
    GROUP BY p.category, s.salesperson
),
ranked AS (
    SELECT
        category,
        salesperson,
        total_sales,
        ROW_NUMBER() OVER (PARTITION BY category ORDER BY total_sales DESC, salesperson ASC) AS rn
    FROM totals
)
SELECT category, salesperson, total_sales
FROM ranked
WHERE rn = 1
ORDER BY category;
""".strip(),
        grader=_optimize_query_grader,
    ),
}
